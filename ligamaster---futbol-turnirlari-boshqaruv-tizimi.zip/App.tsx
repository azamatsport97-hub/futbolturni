
import React, { useState, useEffect } from 'react';
import { TournamentProvider, useTournament } from './context/TournamentContext';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { Tournaments } from './pages/Tournaments';
import { Teams } from './pages/Teams';
import { Matches } from './pages/Matches';
import { Standings } from './pages/Standings';
import { Settings } from './pages/Settings';
import { GroupsOverview } from './pages/GroupsOverview';
import { Playoffs } from './pages/Playoffs';

const AppContent: React.FC = () => {
  const [currentView, setView] = useState('dashboard');
  const { state } = useTournament();
  const isAdmin = state.isAdmin;

  // Protect management views if user switches to user mode while on a management page
  useEffect(() => {
    if (!isAdmin && ['tournaments', 'teams', 'settings'].includes(currentView)) {
      setView('dashboard');
    }
  }, [isAdmin, currentView]);

  const renderView = () => {
    switch (currentView) {
      case 'dashboard': return <Dashboard setView={setView} />;
      case 'tournaments': return isAdmin ? <Tournaments /> : <Dashboard setView={setView} />;
      case 'teams': return isAdmin ? <Teams /> : <Dashboard setView={setView} />;
      case 'groups': return <GroupsOverview />;
      case 'playoffs': return <Playoffs />;
      case 'matches': return <Matches />;
      case 'standings': return <Standings />;
      case 'settings': return isAdmin ? <Settings /> : <Dashboard setView={setView} />;
      default: return <Dashboard setView={setView} />;
    }
  };

  return (
    <Layout currentView={currentView} setView={setView}>
      {renderView()}
    </Layout>
  );
};

const App: React.FC = () => {
  return (
    <TournamentProvider>
      <AppContent />
    </TournamentProvider>
  );
};

export default App;

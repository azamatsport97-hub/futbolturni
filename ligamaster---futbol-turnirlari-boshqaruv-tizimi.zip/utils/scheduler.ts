
import { Team, Match, MatchStatus, StandingEntry } from '../types';

/**
 * Generates round-robin matches for a set of teams.
 */
export const generateRoundRobin = (
  teamIds: string[], 
  groupName: string, 
  isPremium: boolean
): Match[] => {
  const matches: Match[] = [];
  const teams = [...teamIds];
  
  if (teams.length % 2 !== 0) {
    teams.push('REST');
  }

  const numTeams = teams.length;
  const numRounds = numTeams - 1;
  const matchesPerRound = numTeams / 2;

  for (let round = 0; round < numRounds; round++) {
    for (let match = 0; match < matchesPerRound; match++) {
      const home = teams[match];
      const away = teams[numTeams - 1 - match];

      if (home !== 'REST' && away !== 'REST') {
        matches.push({
          id: crypto.randomUUID(),
          homeTeamId: home,
          awayTeamId: away,
          date: new Date().toISOString().split('T')[0],
          time: '18:00',
          status: MatchStatus.PENDING,
          groupName,
          round: round + 1,
          isPlayoff: false
        });
      }
    }
    const lastTeam = teams.pop()!;
    teams.splice(1, 0, lastTeam);
  }

  return matches;
};

// Fixed: Explicitly return StandingEntry[] and use proper typing for the stats accumulator
export const calculateStandings = (matches: Match[], teamIds: string[]): StandingEntry[] => {
  const stats: Record<string, StandingEntry> = {};
  
  teamIds.forEach(id => {
    stats[id] = { teamId: id, played: 0, wins: 0, draws: 0, losses: 0, gf: 0, ga: 0, gd: 0, pts: 0 };
  });

  const playedMatches = matches.filter(m => m.status === MatchStatus.PLAYED);

  playedMatches.forEach(m => {
    const h = m.homeScore || 0;
    const a = m.awayScore || 0;
    
    if (stats[m.homeTeamId] && stats[m.awayTeamId]) {
      stats[m.homeTeamId].played++;
      stats[m.homeTeamId].gf += h;
      stats[m.homeTeamId].ga += a;
      stats[m.homeTeamId].gd = stats[m.homeTeamId].gf - stats[m.homeTeamId].ga;
      
      stats[m.awayTeamId].played++;
      stats[m.awayTeamId].gf += a;
      stats[m.awayTeamId].ga += h;
      stats[m.awayTeamId].gd = stats[m.awayTeamId].gf - stats[m.awayTeamId].ga;

      if (h > a) {
        stats[m.homeTeamId].wins++;
        stats[m.homeTeamId].pts += 3;
        stats[m.awayTeamId].losses++;
      } else if (a > h) {
        stats[m.awayTeamId].wins++;
        stats[m.awayTeamId].pts += 3;
        stats[m.homeTeamId].losses++;
      } else {
        stats[m.homeTeamId].draws++;
        stats[m.awayTeamId].draws++;
        stats[m.homeTeamId].pts += 1;
        stats[m.awayTeamId].pts += 1;
      }
    }
  });

  const standings = Object.values(stats);

  // Sorting with Head-to-Head logic
  return standings.sort((a, b) => {
    // 1. Points
    if (b.pts !== a.pts) return b.pts - a.pts;

    // 2. Head-to-Head (O'zaro o'yinlar)
    const h2hMatches = playedMatches.filter(m => 
      (m.homeTeamId === a.teamId && m.awayTeamId === b.teamId) ||
      (m.homeTeamId === b.teamId && m.awayTeamId === a.teamId)
    );

    let aH2hPts = 0;
    let bH2hPts = 0;

    h2hMatches.forEach(m => {
      const isAHome = m.homeTeamId === a.teamId;
      const hs = m.homeScore || 0;
      const as = m.awayScore || 0;
      
      if (hs === as) {
        aH2hPts += 1;
        bH2hPts += 1;
      } else if (isAHome ? hs > as : as > hs) {
        aH2hPts += 3;
      } else {
        bH2hPts += 3;
      }
    });

    if (bH2hPts !== aH2hPts) return bH2hPts - aH2hPts;

    // 3. Overall Goal Difference (To'plar nisbati)
    if (b.gd !== a.gd) return b.gd - a.gd;

    // 4. Overall Goals Scored (Urilgan gollar)
    return b.gf - a.gf;
  });
};


import { AppState, Tournament } from './types';

const STORAGE_KEY = 'ligamaster_db';
const CLOUD_CONFIG_KEY = 'ligamaster_cloud_config';

interface CloudConfig {
  url: string;
  key: string;
  enabled: boolean;
}

export class ApiService {
  static getCloudConfig(): CloudConfig | null {
    const config = localStorage.getItem(CLOUD_CONFIG_KEY);
    return config ? JSON.parse(config) : null;
  }

  // Supabase orqali ma'lumotlarni olish
  private static async fetchFromCloud(config: CloudConfig): Promise<AppState | null> {
    try {
      // Biz 'app_state' jadvalidan id=1 bo'lgan qatorni olamiz
      const response = await fetch(`${config.url}/rest/v1/app_state?id=eq.1&select=data`, {
        headers: {
          'apikey': config.key,
          'Authorization': `Bearer ${config.key}`,
          'Content-Type': 'application/json'
        }
      });
      const result = await response.json();
      return result[0]?.data || null;
    } catch (e) {
      console.error("Cloud Fetch Error:", e);
      return null;
    }
  }

  // Supabase-ga ma'lumotlarni saqlash
  private static async saveToCloud(config: CloudConfig, data: AppState): Promise<void> {
    try {
      // Ma'lumotni 'upsert' qilish (bor bo'lsa yangilash, yo'q bo'lsa yaratish)
      await fetch(`${config.url}/rest/v1/app_state`, {
        method: 'POST',
        headers: {
          'apikey': config.key,
          'Authorization': `Bearer ${config.key}`,
          'Content-Type': 'application/json',
          'Prefer': 'resolution=merge-duplicates'
        },
        body: JSON.stringify({ id: 1, data: data })
      });
    } catch (e) {
      console.error("Cloud Save Error:", e);
    }
  }

  static async getAppState(): Promise<AppState> {
    const config = this.getCloudConfig();
    if (config?.enabled && config.url && config.key) {
      const cloudData = await this.fetchFromCloud(config);
      if (cloudData) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(cloudData));
        return cloudData;
      }
    }

    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : {
      currentTournamentId: null,
      tournaments: [],
      isPremiumUser: true,
      isAdmin: false,
      theme: 'light',
      adminUsername: 'admin',
      adminPassword: 'qwe123'
    };
  }

  static async saveRawData(data: AppState): Promise<void> {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    const config = this.getCloudConfig();
    if (config?.enabled && config.url && config.key) {
      await this.saveToCloud(config, data);
    }
  }

  static async saveTournament(tournament: Tournament): Promise<void> {
    const data = await this.getAppState();
    const index = data.tournaments.findIndex(t => t.id === tournament.id);
    if (index > -1) {
      data.tournaments[index] = tournament;
    } else {
      data.tournaments.push(tournament);
    }
    await this.saveRawData(data);
  }

  static async deleteTournament(id: string): Promise<void> {
    const data = await this.getAppState();
    data.tournaments = data.tournaments.filter(t => t.id !== id);
    if (data.currentTournamentId === id) data.currentTournamentId = null;
    await this.saveRawData(data);
  }

  static async updateSettings(settings: Partial<AppState>): Promise<void> {
    const data = await this.getAppState();
    const updated = { ...data, ...settings };
    await this.saveRawData(updated);
  }

  static async saveCloudConfig(config: CloudConfig): Promise<void> {
    localStorage.setItem(CLOUD_CONFIG_KEY, JSON.stringify(config));
    // Sozlamalar saqlanganda joriy ma'lumotni bulutga yuklaymiz
    if (config.enabled) {
      const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
      if (data.tournaments) await this.saveToCloud(config, data);
    }
  }
}

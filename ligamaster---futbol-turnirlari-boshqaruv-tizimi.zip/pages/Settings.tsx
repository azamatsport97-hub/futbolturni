
import React, { useRef, useState, useEffect } from 'react';
import { useTournament } from '../context/TournamentContext';
import { uz } from '../translations';
import { ApiService } from '../api';
import { 
  ShieldCheck, 
  Moon, 
  Sun, 
  Check, 
  Database, 
  Download, 
  Upload, 
  Lock, 
  User, 
  KeyRound, 
  Cloud, 
  Globe, 
  Link as LinkIcon,
  Wifi,
  Loader2,
  Copy,
  ExternalLink,
  QrCode,
  Share2,
  Send
} from 'lucide-react';

export const Settings: React.FC = () => {
  const { state, setTheme, exportData, importData, updateAdminCredentials } = useTournament();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [newUsername, setNewUsername] = useState(state.adminUsername || 'admin');
  const [newPassword, setNewPassword] = useState(state.adminPassword || 'qwe123');
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Cloud Sync Settings
  const [cloudUrl, setCloudUrl] = useState('');
  const [cloudKey, setCloudKey] = useState('');
  const [cloudEnabled, setCloudEnabled] = useState(false);
  const [testingCloud, setTestingCloud] = useState(false);
  const [publicLink, setPublicLink] = useState('');
  const [showQr, setShowQr] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('ligamaster_cloud_config');
    if (saved) {
      const parsed = JSON.parse(saved);
      setCloudUrl(parsed.url);
      setCloudKey(parsed.key);
      setCloudEnabled(parsed.enabled);
      
      if (parsed.enabled && parsed.url && parsed.key) {
        generateLink(parsed.url, parsed.key);
      }
    }
  }, []);

  const generateLink = (url: string, key: string) => {
    const baseUrl = window.location.origin + window.location.pathname;
    const fullLink = `${baseUrl}?c_url=${encodeURIComponent(url)}&c_key=${encodeURIComponent(key)}`;
    setPublicLink(fullLink);
  };

  const handleCloudSave = async () => {
    setTestingCloud(true);
    await ApiService.saveCloudConfig({
      url: cloudUrl,
      key: cloudKey,
      enabled: cloudEnabled
    });
    if (cloudEnabled) generateLink(cloudUrl, cloudKey);
    else setPublicLink('');
    
    setTestingCloud(false);
    alert("Bulutli baza sozlamalari saqlandi!");
  };

  const copyToClipboard = () => {
    if (!publicLink) return;
    navigator.clipboard.writeText(publicLink);
    alert("Havola nusxalandi! Endi uni muxlislarga yuborishingiz mumkin.");
  };

  const shareOnTelegram = () => {
    const text = encodeURIComponent(`🏆 ${state.tournaments[0]?.name || 'Turnir'} natijalarini kuzatib boring!\n\nLink: ${publicLink}`);
    window.open(`https://t.me/share/url?url=${publicLink}&text=${text}`, '_blank');
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (importData(content)) alert("Muvaffaqiyatli tiklandi!");
      else alert("Xatolik!");
    };
    reader.readAsText(file);
  };

  const handleUpdateAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    updateAdminCredentials(newUsername, newPassword);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  // QR Code URL (using a free public API for simplicity)
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(publicLink)}`;

  return (
    <div className="max-w-5xl mx-auto space-y-12 animate-fifa pb-24">
      <div className="text-center">
        <h1 className="text-4xl font-black dark:text-white mb-2 uppercase tracking-tight italic-font">{uz.settings}</h1>
        <p className="text-slate-500 font-bold uppercase text-[10px] tracking-widest">Global Boshqaruv va Xavfsizlik</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        
        {/* Cloud Sync - THE GLOBAL BACKEND SOLUTION */}
        <div className="md:col-span-2 bg-gradient-to-br from-[#0a1a2f] to-[#1a3a5f] p-10 rounded-[3rem] shadow-2xl relative overflow-hidden border-b-8 border-[#d4af37]">
          <div className="absolute top-0 right-0 p-10 opacity-10">
            <Cloud className="w-40 h-40 text-white" />
          </div>
          <div className="relative z-10">
            <div className="flex items-center space-x-4 mb-8">
              <div className="w-14 h-14 bg-[#d4af37] rounded-2xl flex items-center justify-center shadow-xl">
                <Globe className="w-8 h-8 text-[#0a1a2f]" />
              </div>
              <div>
                <h3 className="text-3xl font-black text-white uppercase tracking-tighter italic-font leading-none">Global Sinxronizatsiya</h3>
                <p className="text-[#d4af37] text-[9px] font-black uppercase tracking-widest mt-1">Muxlislar uchun real vaqtda ko'rish</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
              <div className="space-y-6">
                <p className="text-slate-300 text-sm leading-relaxed font-medium italic">
                  Supabase-ni ulang va muxlislar uchun maxsus havola generatsiya qiling. Shu havola orqali kirganlar hamma o'zgarishlarni darhol ko'radi.
                </p>
                <div className="flex items-center space-x-4 p-5 bg-white/5 rounded-2xl border border-white/10">
                  <Wifi className={`w-5 h-5 ${cloudEnabled ? 'text-emerald-400' : 'text-slate-500'}`} />
                  <span className="text-white font-bold text-xs uppercase tracking-widest">
                    Holati: {cloudEnabled ? 'Global rejim yoqilgan' : 'Faqat mahalliy (Local)'}
                  </span>
                  <label className="relative inline-flex items-center cursor-pointer ml-auto">
                    <input type="checkbox" checked={cloudEnabled} onChange={(e) => setCloudEnabled(e.target.checked)} className="sr-only peer" />
                    <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                  </label>
                </div>

                {publicLink && (
                  <div className="p-8 bg-emerald-500/10 border-2 border-dashed border-emerald-500/30 rounded-[2.5rem] space-y-6 animate-fifa">
                    <div className="flex items-center justify-between">
                      <span className="text-emerald-400 text-[10px] font-black uppercase tracking-[0.2em]">Ulashish Markazi:</span>
                      <Share2 className="w-5 h-5 text-emerald-500" />
                    </div>
                    
                    <div className="flex flex-wrap gap-4">
                       <button onClick={copyToClipboard} className="flex-1 min-w-[120px] bg-white/10 hover:bg-white/20 text-white p-4 rounded-2xl flex flex-col items-center gap-2 transition-all">
                          <Copy className="w-5 h-5" />
                          <span className="text-[8px] font-black uppercase tracking-widest">Nusxalash</span>
                       </button>
                       <button onClick={() => setShowQr(true)} className="flex-1 min-w-[120px] bg-[#d4af37] text-[#0a1a2f] p-4 rounded-2xl flex flex-col items-center gap-2 transition-all hover:scale-105">
                          <QrCode className="w-5 h-5" />
                          <span className="text-[8px] font-black uppercase tracking-widest">QR Kod</span>
                       </button>
                       <button onClick={shareOnTelegram} className="flex-1 min-w-[120px] bg-[#24A1DE] text-white p-4 rounded-2xl flex flex-col items-center gap-2 transition-all hover:scale-105">
                          <Send className="w-5 h-5" />
                          <span className="text-[8px] font-black uppercase tracking-widest">Telegram</span>
                       </button>
                    </div>

                    <p className="text-[8px] text-emerald-500/60 font-medium text-center italic">Muxlislar bu havola orqali real vaqtda natijalarni ko'rishadi!</p>
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Supabase API URL</label>
                  <div className="relative">
                    <LinkIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                    <input type="text" value={cloudUrl} onChange={(e) => setCloudUrl(e.target.value)} placeholder="https://xyz.supabase.co" className="w-full pl-12 pr-6 py-4 rounded-xl bg-black/30 border-2 border-white/10 text-white font-bold outline-none focus:border-[#d4af37] transition-all" />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Supabase Anon Key</label>
                  <div className="relative">
                    <KeyRound className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                    <input type="password" value={cloudKey} onChange={(e) => setCloudKey(e.target.value)} placeholder="API Key..." className="w-full pl-12 pr-6 py-4 rounded-xl bg-black/30 border-2 border-white/10 text-white font-bold outline-none focus:border-[#d4af37] transition-all" />
                  </div>
                </div>
                <button 
                  onClick={handleCloudSave}
                  disabled={testingCloud}
                  className="w-full py-4 bg-[#d4af37] text-[#0a1a2f] rounded-xl font-black uppercase text-[11px] tracking-widest hover:scale-[1.02] active:scale-95 transition-all shadow-2xl flex items-center justify-center space-x-3"
                >
                  {testingCloud ? <Loader2 className="w-5 h-5 animate-spin" /> : <span>Global Rejimni Saqlash</span>}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Security & Appearance */}
        <div className="fifa-card p-10 rounded-[2.5rem] flex flex-col h-full broadcast-shadow">
          <h3 className="text-xl font-black dark:text-white mb-8 flex items-center uppercase tracking-tight">
            <Lock className="w-6 h-6 mr-3 text-[#8a1538]" />
            Admin Xavfsizligi
          </h3>
          <form onSubmit={handleUpdateAdmin} className="space-y-5 flex-1">
            <div className="space-y-1.5">
              <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">{uz.admin_login}</label>
              <input type="text" value={newUsername} onChange={(e) => setNewUsername(e.target.value)} className="w-full px-6 py-4 rounded-xl border-2 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-slate-100 dark:border-slate-800 focus:border-[#8a1538]" />
            </div>
            <div className="space-y-1.5">
              <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">{uz.admin_pass}</label>
              <input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} className="w-full px-6 py-4 rounded-xl border-2 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-slate-100 dark:border-slate-800 focus:border-[#8a1538]" />
            </div>
            <button type="submit" className={`w-full py-5 rounded-xl font-black uppercase text-[11px] tracking-widest shadow-xl transition-all ${saveSuccess ? 'bg-emerald-500 text-white' : 'bg-[#8a1538] text-white hover:bg-red-800'}`}>
              {saveSuccess ? 'SAQLANDI!' : 'O\'ZGARTIRISHNI SAQLASH'}
            </button>
          </form>
        </div>

        <div className="fifa-card p-10 rounded-[2.5rem] flex flex-col h-full broadcast-shadow">
          <h3 className="text-xl font-black dark:text-white mb-8 flex items-center uppercase tracking-tight">
            <Sun className="w-6 h-6 mr-3 text-[#8a1538]" />
            Tizim Ko'rinishi
          </h3>
          <div className="grid grid-cols-2 gap-4 flex-1">
            <button onClick={() => setTheme('light')} className={`p-8 rounded-3xl border-4 transition-all flex flex-col items-center justify-center space-y-3 ${state.theme === 'light' ? 'border-[#8a1538] bg-red-50' : 'border-slate-100'}`}>
               <Sun className={`w-10 h-10 ${state.theme === 'light' ? 'text-[#8a1538]' : 'text-slate-300'}`} />
               <span className="font-black text-[10px] uppercase tracking-widest">KUNDUZGI</span>
            </button>
            <button onClick={() => setTheme('dark')} className={`p-8 rounded-3xl border-4 transition-all flex flex-col items-center justify-center space-y-3 ${state.theme === 'dark' ? 'border-[#d4af37] bg-[#0a1a2f]' : 'border-slate-100 dark:border-slate-800'}`}>
               <Moon className={`w-10 h-10 ${state.theme === 'dark' ? 'text-[#d4af37]' : 'text-slate-300'}`} />
               <span className="font-black text-[10px] uppercase tracking-widest dark:text-white">TUNGI</span>
            </button>
          </div>
        </div>
      </div>

      {/* QR Code Modal */}
      {showQr && (
        <div className="fixed inset-0 bg-[#0a1a2f]/95 backdrop-blur-md flex items-center justify-center z-[250] p-4">
          <div className="bg-white p-12 rounded-[3rem] shadow-2xl max-w-sm w-full text-center relative animate-fifa">
            <button onClick={() => setShowQr(false)} className="absolute top-8 right-8 text-slate-400 hover:text-black">
              <Copy className="w-6 h-6 rotate-45" />
            </button>
            <div className="mb-8">
               <h3 className="text-2xl font-black uppercase italic-font text-[#0a1a2f]">Turnir QR Kodi</h3>
               <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mt-1">Skaner qiling va kuzating</p>
            </div>
            <div className="bg-slate-50 p-6 rounded-3xl mb-8 flex items-center justify-center">
               <img src={qrCodeUrl} alt="QR Code" className="w-full h-auto rounded-xl shadow-inner" />
            </div>
            <p className="text-[9px] font-medium text-slate-500 italic leading-relaxed mb-8">
              Ushbu QR kodni stadionda yoki guruhlarda chop etishingiz mumkin. Muxlislar shunchaki skaner qilib, real vaqtda turnir jadvaliga kirishadi.
            </p>
            <button 
              onClick={() => window.print()}
              className="w-full py-4 bg-[#8a1538] text-white rounded-xl font-black uppercase text-[11px] tracking-widest shadow-xl"
            >
              CHOP ETISH
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

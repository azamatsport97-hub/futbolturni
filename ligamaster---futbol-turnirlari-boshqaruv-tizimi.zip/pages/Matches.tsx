
import React, { useState } from 'react';
import { useTournament } from '../context/TournamentContext';
import { uz } from '../translations';
import { Calendar, Clock, Edit2, CheckCircle2, Trash2, Plus, AlertTriangle, Trophy, Zap, X, Globe, FileSpreadsheet, Hash } from 'lucide-react';
import { MatchStatus, Match } from '../types';

export const Matches: React.FC = () => {
  const { state, addMatch, updateMatch, deleteMatch } = useTournament();
  const currentTournament = state.tournaments.find(t => t.id === state.currentTournamentId);
  const isAdmin = state.isAdmin;
  
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingMatchId, setEditingMatchId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  
  const [scores, setScores] = useState({ home: 0, away: 0 });
  const [newMatch, setNewMatch] = useState({
    groupId: '',
    homeTeamId: '',
    awayTeamId: '',
    round: 1,
    date: new Date().toISOString().split('T')[0],
    time: '18:00'
  });

  if (!currentTournament) return (
    <div className="flex flex-col items-center justify-center py-20 text-center animate-fifa">
      <Globe className="w-20 h-20 text-slate-200 dark:text-slate-800 mb-6" />
      <h2 className="text-xl font-black dark:text-white text-slate-400 uppercase tracking-tight italic-font">{uz.not_found}</h2>
    </div>
  );

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    const [year, month, day] = dateStr.split('-');
    return `${day}.${month}.${year}`;
  };

  const handleDeleteMatch = () => {
    if (confirmDeleteId && currentTournament) {
      deleteMatch(currentTournament.id, confirmDeleteId);
      setConfirmDeleteId(null);
    }
  };

  const exportAllMatchesToExcel = () => {
    const fileName = `${currentTournament.name}_Barcha_Oyinlar.xls`;
    
    let tableHtml = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta charset="utf-8">
        <style>
          .header { background-color: #0a1a2f; color: #ffffff; font-weight: bold; text-align: center; }
          .title { font-size: 16pt; font-weight: bold; text-align: center; color: #8a1538; }
          .cell { border: 0.5pt solid #cccccc; padding: 5px; mso-number-format:"\\@"; }
          .num-cell { text-align: center; border: 0.5pt solid #cccccc; mso-number-format:"0"; }
          .vs-cell { font-weight: bold; background-color: #f0f0f0; text-align: center; border: 0.5pt solid #cccccc; mso-number-format:"\\@"; }
        </style>
      </head>
      <body>
        <table>
          <tr><td colspan="7" class="title">${currentTournament.name} - O'YINLAR TAQVIMI</td></tr>
          <tr><td></td></tr>
          <tr class="header">
            <td class="cell">${uz.round}</td>
            <td class="cell">${uz.group_name}</td>
            <td class="cell">${uz.match_date}</td>
            <td class="cell" style="width: 150px;">${uz.home}</td>
            <td class="cell">${uz.score}</td>
            <td class="cell" style="width: 150px;">${uz.away}</td>
            <td class="cell">Holati</td>
          </tr>
    `;

    const sortedMatches = [...currentTournament.matches].sort((a, b) => {
      if (a.isPlayoff !== b.isPlayoff) return a.isPlayoff ? 1 : -1;
      return a.round - b.round;
    });

    sortedMatches.forEach(m => {
      const ht = currentTournament.teams.find(t => t.id === m.homeTeamId);
      const at = currentTournament.teams.find(t => t.id === m.awayTeamId);
      const scoreStr = m.status === MatchStatus.PLAYED ? `${m.homeScore}-${m.awayScore}` : "VS";
      const groupOrStage = m.isPlayoff ? m.playoffRoundName : m.groupName;
      const statusText = m.status === MatchStatus.PLAYED ? "Yakunlangan" : "Kutilmoqda";

      tableHtml += `
        <tr>
          <td class="num-cell">${m.isPlayoff ? "PLEY-OFF" : m.round}</td>
          <td class="cell">${groupOrStage || ''}</td>
          <td class="cell">${formatDate(m.date)} ${m.time}</td>
          <td class="cell" style="text-align: right;">${ht?.name || ''}</td>
          <td class="vs-cell">${scoreStr}</td>
          <td class="cell">${at?.name || ''}</td>
          <td class="cell">${statusText}</td>
        </tr>
      `;
    });

    tableHtml += `
        </table>
      </body>
      </html>
    `;

    const blob = new Blob([tableHtml], { type: 'application/vnd.ms-excel' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCreateMatch = () => {
    if (!newMatch.groupId || !newMatch.homeTeamId || !newMatch.awayTeamId) {
      alert("Barcha maydonlarni to'ldiring!");
      return;
    }
    const group = currentTournament.groups.find(g => g.id === newMatch.groupId);
    const match: Match = {
      id: crypto.randomUUID(),
      homeTeamId: newMatch.homeTeamId,
      awayTeamId: newMatch.awayTeamId,
      round: newMatch.round,
      date: newMatch.date,
      time: newMatch.time,
      groupName: group?.name || '',
      status: MatchStatus.PENDING,
      isPlayoff: false
    };
    addMatch(currentTournament.id, match);
    setShowAddModal(false);
  };

  const handleSaveScore = (matchId: string) => {
    const match = currentTournament.matches.find(m => m.id === matchId);
    if (!match) return;
    updateMatch(currentTournament.id, {
      ...match,
      homeScore: scores.home,
      awayScore: scores.away,
      status: MatchStatus.PLAYED
    });
    setEditingMatchId(null);
  };

  const groupNames = Array.from(new Set(currentTournament.matches.filter(m => !m.isPlayoff).map(m => m.groupName))).sort();
  const playoffMatches = currentTournament.matches.filter(m => m.isPlayoff);

  return (
    <div className="space-y-12 animate-fifa pb-24">
      <div className="bg-[#8a1538] p-10 rounded-[2rem] shadow-2xl relative overflow-hidden flex flex-col md:flex-row justify-between items-center gap-8 border-b-8 border-[#d4af37]">
        <div className="absolute inset-0 bg-white opacity-5 pointer-events-none">
           <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
             <path d="M0,100 L100,0 L100,100 Z" />
           </svg>
        </div>
        <div className="relative z-10 text-center md:text-left">
          <h1 className="text-5xl font-black text-white uppercase tracking-tighter italic-font leading-none">{uz.matches}</h1>
          <p className="text-[10px] font-black text-[#d4af37] uppercase tracking-[0.4em] mt-3">{uz.game_administration}</p>
        </div>
        <div className="flex gap-4 relative z-10">
          <button 
            onClick={exportAllMatchesToExcel}
            className="bg-white text-[#8a1538] px-8 py-5 rounded-xl text-[11px] font-black uppercase tracking-widest shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center"
          >
            <FileSpreadsheet className="w-4 h-4 mr-2" />
            Excelga Yuklash (.xls)
          </button>
          {isAdmin && (
            <button 
              onClick={() => setShowAddModal(true)}
              className="fifa-btn-gold px-10 py-5 rounded-xl text-[11px] font-black uppercase tracking-widest shadow-2xl hover:scale-105 active:scale-95 transition-all"
            >
              {uz.new_fixture}
            </button>
          )}
        </div>
      </div>

      <div className="space-y-20">
        {playoffMatches.length > 0 && (
          <section className="space-y-10">
            <div className="flex items-center space-x-6">
              <Trophy className="w-8 h-8 text-[#d4af37]" />
              <h2 className="text-3xl font-black dark:text-white uppercase tracking-tighter italic-font">{uz.knockout_stage}</h2>
              <div className="flex-1 h-1 bg-[#d4af37] opacity-20"></div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {playoffMatches.map(match => {
                const ht = currentTournament.teams.find(t => t.id === match.homeTeamId);
                const at = currentTournament.teams.find(t => t.id === match.awayTeamId);
                const isPlayed = match.status === MatchStatus.PLAYED;

                return (
                  <div key={match.id} className="fifa-card rounded-2xl p-10 broadcast-shadow group flex flex-col items-center border-t-8 border-t-[#0a1a2f]">
                    <div className="bg-[#8a1538] text-[#d4af37] px-6 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest mb-10">
                      {match.playoffRoundName}
                    </div>

                    <div className="w-full flex items-center justify-between gap-4 mb-8 min-h-[6rem]">
                       <div className="flex-1 text-center py-2">
                          <span className="font-black dark:text-white text-[11px] uppercase tracking-tighter leading-tight line-clamp-3 break-words min-h-[3rem] flex items-center justify-center">{ht?.name}</span>
                       </div>

                       <div className={`px-5 py-3 rounded-xl text-3xl font-black italic-font tracking-tighter shadow-2xl min-w-[95px] text-center shrink-0 ${isPlayed ? 'bg-[#0a1a2f] text-[#d4af37]' : 'bg-slate-50 text-slate-300 dark:bg-slate-800'}`}>
                          {isPlayed ? `${match.homeScore}:${match.awayScore}` : 'VS'}
                       </div>

                       <div className="flex-1 text-center py-2">
                          <span className="font-black dark:text-white text-[11px] uppercase tracking-tighter leading-tight line-clamp-3 break-words min-h-[3rem] flex items-center justify-center">{at?.name}</span>
                       </div>
                    </div>

                    <div className="flex items-center space-x-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                       <span>{formatDate(match.date)}</span>
                       <span className="w-1.5 h-1.5 bg-[#d4af37] rounded-full"></span>
                       <span>{match.time}</span>
                    </div>

                    {isAdmin && (
                      <div className="mt-8 flex items-center space-x-6">
                        <button onClick={() => {setEditingMatchId(match.id); setScores({home: match.homeScore || 0, away: match.awayScore || 0})}} className="text-[#8a1538] dark:text-[#d4af37] font-black text-[10px] uppercase tracking-widest hover:underline">
                          {uz.set_score}
                        </button>
                        <button onClick={() => setConfirmDeleteId(match.id)} className="p-2 text-slate-300 hover:text-red-600 transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {groupNames.map(groupName => {
          const groupMatches = currentTournament.matches.filter(m => m.groupName === groupName && !m.isPlayoff);
          const rounds = Array.from(new Set(groupMatches.map(m => m.round))).sort((a: number, b: number) => a - b);

          return (
            <section key={groupName} className="space-y-12">
              <div className="flex items-center space-x-6">
                <div className="bg-[#0a1a2f] dark:bg-white text-white dark:text-[#0a1a2f] px-10 py-3 rounded-xl font-black text-2xl uppercase italic-font tracking-tighter shadow-2xl">
                  {groupName}
                </div>
                <div className="flex-1 h-1 bg-[#8a1538] opacity-10"></div>
              </div>

              <div className="space-y-16">
                {rounds.map(round => (
                  <div key={`${groupName}-${round}`} className="space-y-8">
                    <div className="flex items-center space-x-4 ml-6">
                       <span className="text-[12px] font-black text-[#8a1538] dark:text-[#d4af37] uppercase tracking-[0.4em]">{round}-{uz.matchday}</span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                      {groupMatches.filter(m => m.round === round).map(match => {
                        const ht = currentTournament.teams.find(t => t.id === match.homeTeamId);
                        const at = currentTournament.teams.find(t => t.id === match.awayTeamId);
                        const isPlayed = match.status === MatchStatus.PLAYED;
                        const isEditing = editingMatchId === match.id;

                        return (
                          <div key={match.id} className="fifa-card rounded-2xl p-8 broadcast-shadow group flex flex-col items-center border-t-4 border-t-[#0a1a2f]">
                            <div className="w-full flex items-center justify-between gap-4 mb-8 min-h-[5rem]">
                               <div className="flex-1 text-center py-2">
                                  <span className="font-black dark:text-white text-[11px] uppercase tracking-tighter leading-tight line-clamp-3 break-words min-h-[2.5rem] flex items-center justify-center">{ht?.name}</span>
                               </div>
                               
                               <div className="flex flex-col items-center justify-center shrink-0">
                                 {isEditing ? (
                                    <div className="flex items-center space-x-1">
                                      <input type="number" value={scores.home} onChange={e => setScores({...scores, home: parseInt(e.target.value) || 0})} className="w-10 h-10 text-center bg-white dark:bg-[#0a1a2f] border-2 border-[#8a1538] rounded-lg outline-none font-black text-lg dark:text-white" />
                                      <span className="font-black text-[#d4af37] text-xl">:</span>
                                      <input type="number" value={scores.away} onChange={e => setScores({...scores, away: parseInt(e.target.value) || 0})} className="w-10 h-10 text-center bg-white dark:bg-[#0a1a2f] border-2 border-[#8a1538] rounded-lg outline-none font-black text-lg dark:text-white" />
                                    </div>
                                 ) : (
                                    <div className={`px-5 py-2.5 rounded-xl font-black text-3xl italic-font tracking-tighter shadow-2xl min-w-[90px] text-center ${isPlayed ? 'bg-[#0a1a2f] text-[#d4af37]' : 'bg-slate-100 text-slate-300 dark:bg-slate-800 dark:text-slate-700'}`}>
                                      {isPlayed ? `${match.homeScore}:${match.awayScore}` : 'VS'}
                                    </div>
                                 )}
                               </div>

                               <div className="flex-1 text-center py-2">
                                  <span className="font-black dark:text-white text-[11px] uppercase tracking-tighter leading-tight line-clamp-3 break-words min-h-[2.5rem] flex items-center justify-center">{at?.name}</span>
                               </div>
                            </div>

                            <div className="w-full flex justify-between items-center border-t border-slate-100 dark:border-slate-800 pt-6">
                               <span className="text-[10px] font-black text-[#8a1538] dark:text-[#d4af37] uppercase tracking-widest">{formatDate(match.date)}</span>
                               <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{match.time}</span>
                            </div>

                            {isAdmin && (
                              <div className="w-full mt-6 pt-4 flex justify-center space-x-6">
                                {isEditing ? (
                                   <button onClick={() => handleSaveScore(match.id)} className="text-emerald-600 font-black text-[10px] uppercase tracking-widest flex items-center">
                                     <CheckCircle2 className="w-4 h-4 mr-2" /> {uz.save}
                                   </button>
                                ) : (
                                   <>
                                     <button onClick={() => {setEditingMatchId(match.id); setScores({home: match.homeScore || 0, away: match.awayScore || 0})}} className="text-slate-400 hover:text-[#8a1538] font-black text-[9px] uppercase tracking-widest flex items-center transition-colors">
                                       <Edit2 className="w-3 h-3 mr-2" /> {uz.set_score}
                                     </button>
                                     <button onClick={() => setConfirmDeleteId(match.id)} className="text-slate-200 hover:text-red-700 transition-colors">
                                       <Trash2 className="w-4 h-4" />
                                     </button>
                                   </>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          );
        })}
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-[#0a1a2f]/90 backdrop-blur-md flex items-center justify-center z-[100] p-4">
          <div className="bg-white dark:bg-[#0f2238] w-full max-w-lg p-12 rounded-[2rem] shadow-2xl border-t-8 border-[#8a1538] animate-fifa relative">
            <button onClick={() => setShowAddModal(false)} className="absolute top-8 right-8 text-slate-400 hover:text-slate-900 transition-colors">
              <X className="w-8 h-8" />
            </button>
            <h3 className="text-4xl font-black dark:text-white uppercase tracking-tight italic-font mb-10">{uz.new_fixture}</h3>
            
            <div className="space-y-6">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{uz.select_group}</label>
                <select 
                  value={newMatch.groupId}
                  onChange={(e) => setNewMatch({...newMatch, groupId: e.target.value, homeTeamId: '', awayTeamId: ''})}
                  className="w-full px-6 py-4 rounded-xl bg-slate-50 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-2 border-slate-100 dark:border-slate-800 focus:border-[#8a1538]"
                >
                  <option value="">{uz.select_group}...</option>
                  {currentTournament.groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{uz.home}</label>
                  <select 
                    value={newMatch.homeTeamId}
                    onChange={(e) => setNewMatch({...newMatch, homeTeamId: e.target.value})}
                    className="w-full px-5 py-4 rounded-xl bg-slate-50 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-2 border-slate-100 dark:border-slate-800 focus:border-[#8a1538]"
                  >
                    <option value="">{uz.home}...</option>
                    {currentTournament.teams.filter(t => t.groupId === newMatch.groupId).map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{uz.away}</label>
                  <select 
                    value={newMatch.awayTeamId}
                    onChange={(e) => setNewMatch({...newMatch, awayTeamId: e.target.value})}
                    className="w-full px-5 py-4 rounded-xl bg-slate-50 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-2 border-slate-100 dark:border-slate-800 focus:border-[#8a1538]"
                  >
                    <option value="">{uz.away}...</option>
                    {currentTournament.teams.filter(t => t.groupId === newMatch.groupId && t.id !== newMatch.homeTeamId).map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 flex items-center">
                    <Hash className="w-3 h-3 mr-1" /> {uz.round}
                  </label>
                  <input 
                    type="number" 
                    min="1"
                    value={newMatch.round} 
                    onChange={e => setNewMatch({...newMatch, round: parseInt(e.target.value) || 1})} 
                    className="w-full px-5 py-4 rounded-xl bg-slate-50 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-2 border-slate-100 dark:border-slate-800 focus:border-[#8a1538]" 
                  />
                </div>
                <div className="space-y-1.5 col-span-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{uz.match_date}</label>
                  <input type="date" value={newMatch.date} onChange={e => setNewMatch({...newMatch, date: e.target.value})} className="w-full px-5 py-4 rounded-xl bg-slate-50 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-2 border-slate-100 dark:border-slate-800 focus:border-[#8a1538]" />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{uz.match_time}</label>
                <input type="time" value={newMatch.time} onChange={e => setNewMatch({...newMatch, time: e.target.value})} className="w-full px-5 py-4 rounded-xl bg-slate-50 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-2 border-slate-100 dark:border-slate-800 focus:border-[#8a1538]" />
              </div>

              <button 
                onClick={handleCreateMatch}
                className="w-full py-5 bg-[#8a1538] text-white rounded-xl font-black uppercase text-[12px] tracking-widest shadow-2xl hover:bg-[#5e0e26] transition-all mt-6"
              >
                {uz.schedule_match}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* O'chirishni tasdiqlash modali */}
      {confirmDeleteId && (
        <div className="fixed inset-0 bg-[#0a1a2f]/90 backdrop-blur-md flex items-center justify-center z-[200] p-4">
          <div className="bg-white dark:bg-[#0f2238] w-full max-w-sm p-12 rounded-[2rem] shadow-2xl text-center border-t-8 border-red-700 animate-fifa">
            <AlertTriangle className="w-16 h-16 text-red-700 mx-auto mb-6" />
            <h3 className="text-2xl font-black dark:text-white uppercase italic-font mb-4">{uz.delete_confirm}</h3>
            <p className="text-gray-500 dark:text-gray-400 mb-10 text-sm italic">
              {uz.confirm_delete_match} {uz.delete_warning}
            </p>
            <div className="grid grid-cols-2 gap-4">
              <button onClick={() => setConfirmDeleteId(null)} className="py-4 rounded-xl font-black uppercase text-[10px] tracking-widest text-gray-400 bg-gray-50 dark:bg-gray-800">{uz.no_keep}</button>
              <button onClick={handleDeleteMatch} className="py-4 rounded-xl font-black uppercase text-[10px] tracking-widest text-white bg-red-700 shadow-xl">{uz.yes_delete}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

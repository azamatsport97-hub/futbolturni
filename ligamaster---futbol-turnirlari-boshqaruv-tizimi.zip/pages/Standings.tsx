
import React from 'react';
import { useTournament } from '../context/TournamentContext';
import { uz } from '../translations';
import { calculateStandings } from '../utils/scheduler';
import { FileSpreadsheet, Download, Trophy, Globe, Zap, Calendar, Clock } from 'lucide-react';
import { MatchStatus, Match } from '../types';

export const Standings: React.FC = () => {
  const { state } = useTournament();
  const currentTournament = state.tournaments.find(t => t.id === state.currentTournamentId);

  if (!currentTournament) return (
    <div className="flex flex-col items-center justify-center py-20 text-center animate-fifa">
      <Globe className="w-20 h-20 text-slate-200 dark:text-slate-800 mb-6" />
      <h2 className="text-xl font-black dark:text-white text-slate-400 uppercase tracking-tight italic-font">{uz.not_found}</h2>
    </div>
  );

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    const [year, month, day] = dateStr.split('-');
    return `${day}.${month}.${year}`;
  };

  const exportFullTournamentExcel = () => {
    const fileName = `${currentTournament.name}_Toliq_Hisobot.xls`;
    
    let tableHtml = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: 'Arial', sans-serif; }
          .title { font-size: 22pt; font-weight: bold; text-align: center; color: #8a1538; padding: 20px; border: none; }
          .group-header { font-size: 18pt; font-weight: bold; background-color: #0a1a2f; color: #ffffff; text-align: center; padding: 15px; border: 1pt solid #000; }
          .section-title { font-size: 14pt; font-weight: bold; background-color: #f3f4f6; color: #000000; padding: 10px; border: 1pt solid #000000; text-align: center; }
          .header-cell { background-color: #8a1538; color: #ffffff; font-weight: bold; text-align: center; border: 1pt solid #000000; font-size: 11pt; height: 35px; vertical-align: middle; }
          .cell { border: 1pt solid #000000; padding: 8px; text-align: left; font-size: 11pt; color: #000000; mso-number-format:"\\@"; vertical-align: middle; background-color: #ffffff; }
          .num-cell { border: 1pt solid #000000; text-align: center; font-size: 11pt; color: #000000; mso-number-format:"0"; vertical-align: middle; }
          .pts-cell { border: 1pt solid #000000; font-weight: bold; background-color: #fff7ed; text-align: center; font-size: 12pt; color: #c2410c; mso-number-format:"0"; vertical-align: middle; }
          .vs-cell { border: 1pt solid #000000; font-weight: bold; text-align: center; color: #8a1538; background-color: #f9fafb; font-size: 11pt; mso-number-format:"\\@"; vertical-align: middle; }
          .spacer { height: 25px; border: none; }
        </style>
      </head>
      <body>
        <table>
          <col width="50"> <col width="250"> <col width="60"> <col width="60"> <col width="60"> <col width="60"> <col width="60"> <col width="60"> <col width="60"> <col width="100">
          <tr><td colspan="10" class="title">${currentTournament.name.toUpperCase()} - RASMIY HISOBOT</td></tr>
    `;

    // 1. Guruhlar va ularning jadvallari
    currentTournament.groups.forEach(group => {
      const groupMatches = currentTournament.matches.filter(m => m.groupName === group.name && !m.isPlayoff);
      const groupStandings = calculateStandings(groupMatches, group.teams);

      tableHtml += `
        <tr class="spacer"><td colspan="10"></td></tr>
        <tr><td colspan="10" class="group-header">${group.name.toUpperCase()}</td></tr>
        <tr><td colspan="10" class="section-title">TURNIR JADVALI</td></tr>
        <tr class="header-cell">
          <td>№</td>
          <td style="text-align: left; padding-left: 10px;">Jamoa Nomi</td>
          <td>O'</td> <td>G'</td> <td>D</td> <td>M</td> <td>UG</td> <td>O'G</td> <td>TN</td> <td>Ochko</td>
        </tr>
      `;

      groupStandings.forEach((entry, idx) => {
        const team = currentTournament.teams.find(t => t.id === entry.teamId);
        tableHtml += `
          <tr>
            <td class="num-cell">${idx + 1}</td>
            <td class="cell" style="font-weight: bold;">${team?.name || 'Noma\'lum'}</td>
            <td class="num-cell">${entry.played}</td>
            <td class="num-cell">${entry.wins}</td>
            <td class="num-cell">${entry.draws}</td>
            <td class="num-cell">${entry.losses}</td>
            <td class="num-cell">${entry.gf}</td>
            <td class="num-cell">${entry.ga}</td>
            <td class="num-cell">${entry.gd > 0 ? '+' + entry.gd : entry.gd}</td>
            <td class="pts-cell">${entry.pts}</td>
          </tr>
        `;
      });

      // Shu guruh o'yinlari
      tableHtml += `
        <tr class="spacer"><td colspan="10"></td></tr>
        <tr><td colspan="10" class="section-title">${group.name} - O'YINLAR NATIJALARI</td></tr>
        <tr class="header-cell">
          <td>Tur</td>
          <td colspan="2">Sana / Vaqt</td>
          <td colspan="3" style="text-align: right;">Mezbon</td>
          <td>Hisob</td>
          <td colspan="3">Mehmon</td>
        </tr>
      `;

      // Fixed: Explicitly typed 'a' and 'b' as numbers to resolve arithmetic operation errors
      const rounds = Array.from(new Set(groupMatches.map(m => m.round))).sort((a: number, b: number) => a - b);
      rounds.forEach(rNum => {
        groupMatches.filter(m => m.round === rNum).forEach(m => {
          const ht = currentTournament.teams.find(t => t.id === m.homeTeamId);
          const at = currentTournament.teams.find(t => t.id === m.awayTeamId);
          const scoreStr = m.status === MatchStatus.PLAYED ? `${m.homeScore}:${m.awayScore}` : "VS";
          tableHtml += `
            <tr>
              <td class="num-cell">${rNum}</td>
              <td colspan="2" class="cell" style="text-align: center; font-size: 9pt;">${formatDate(m.date)} ${m.time}</td>
              <td colspan="3" class="cell" style="text-align: right; font-weight: bold;">${ht?.name || ''}</td>
              <td class="vs-cell">${scoreStr}</td>
              <td colspan="3" class="cell" style="font-weight: bold;">${at?.name || ''}</td>
            </tr>
          `;
        });
      });
    });

    // 2. Pley-off bosqichi (agar bo'lsa)
    const playoffMatches = currentTournament.matches.filter(m => m.isPlayoff);
    if (playoffMatches.length > 0) {
      tableHtml += `
        <tr class="spacer"><td colspan="10"></td></tr>
        <tr><td colspan="10" class="group-header">PLEY-OFF (CHIQUB KETISH BOSQICHI)</td></tr>
        <tr class="header-cell">
          <td colspan="2">Bosqich</td>
          <td colspan="2">Sana</td>
          <td colspan="2" style="text-align: right;">Jamoa 1</td>
          <td>Hisob</td>
          <td colspan="3">Jamoa 2</td>
        </tr>
      `;

      playoffMatches.forEach(m => {
        const ht = currentTournament.teams.find(t => t.id === m.homeTeamId);
        const at = currentTournament.teams.find(t => t.id === m.awayTeamId);
        const scoreStr = m.status === MatchStatus.PLAYED ? `${m.homeScore}:${m.awayScore}` : "VS";
        tableHtml += `
          <tr>
            <td colspan="2" class="cell" style="font-weight: bold; background-color: #fffbeb;">${m.playoffRoundName}</td>
            <td colspan="2" class="cell" style="text-align: center;">${formatDate(m.date)} ${m.time}</td>
            <td colspan="2" class="cell" style="text-align: right; font-weight: bold;">${ht?.name || '???'}</td>
            <td class="vs-cell" style="background-color: #0a1a2f; color: #d4af37;">${scoreStr}</td>
            <td colspan="3" class="cell" style="font-weight: bold;">${at?.name || '???'}</td>
          </tr>
        `;
      });
    }

    tableHtml += `</table></body></html>`;

    const blob = new Blob([tableHtml], { type: 'application/vnd.ms-excel' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-16 pb-24 animate-fifa">
      {/* Header UI qismi o'zgarmaydi, faqat funksiya to'g'irlandi */}
      <div className="bg-[#8a1538] p-10 rounded-[2rem] shadow-2xl relative overflow-hidden flex flex-col md:flex-row justify-between items-center gap-8 border-b-8 border-[#d4af37] no-print">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-white opacity-5 rotate-12 -translate-y-10"></div>
        <div className="flex items-center space-x-6 relative z-10">
          <div className="bg-white/10 p-5 rounded-2xl border border-white/20">
            <Trophy className="w-10 h-10 text-[#d4af37]" />
          </div>
          <div>
            <h1 className="text-4xl font-black text-white uppercase tracking-tighter italic-font leading-none">{uz.standings}</h1>
            <p className="text-[10px] font-black text-[#d4af37] uppercase tracking-[0.4em] mt-2">Rasmiy Jadval va Natijalar</p>
          </div>
        </div>
        
        <div className="flex flex-wrap justify-center gap-4 relative z-10">
          <button 
            onClick={exportFullTournamentExcel}
            className="fifa-btn-gold px-8 py-4 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center"
          >
            <FileSpreadsheet className="w-5 h-5 mr-3" />
            Excel Hisobot
          </button>
          <button 
            onClick={() => window.print()} 
            className="bg-white text-[#8a1538] px-8 py-4 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl hover:bg-slate-50 transition-all flex items-center"
          >
            <Download className="w-4 h-4 mr-2" />
            {uz.export_pdf}
          </button>
        </div>
      </div>

      <div className="space-y-24">
        {currentTournament.groups.map((group) => {
          const groupMatches = currentTournament.matches.filter(m => m.groupName === group.name);
          const groupStandings = calculateStandings(groupMatches, group.teams);
          
          const roundsMap: Record<number, Match[]> = {};
          groupMatches.forEach(m => {
            if (!roundsMap[m.round]) roundsMap[m.round] = [];
            roundsMap[m.round].push(m);
          });
          // Fixed: Explicitly typed 'a' and 'b' as numbers to resolve arithmetic operation errors
          const sortedRounds = Object.keys(roundsMap).map(Number).sort((a: number, b: number) => a - b);
          
          return (
            <div key={group.id} className="space-y-14 animate-fifa page-break-after">
              <div className="flex items-center justify-between">
                <div className="bg-[#0a1a2f] dark:bg-white text-white dark:text-[#0a1a2f] px-12 py-4 rounded-2xl font-black text-3xl uppercase italic-font tracking-tighter shadow-2xl border-b-4 border-[#d4af37]">
                  {group.name}
                </div>
              </div>

              {/* Standings Table UI */}
              <div className="fifa-card rounded-[2.5rem] shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0f2238]">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-[#0a1a2f] text-white">
                      <th className="px-6 py-5 text-[11px] font-black uppercase text-center w-16 border-r border-white/5">{uz.standing_pos}</th>
                      <th className="px-6 py-5 text-[11px] font-black uppercase">{uz.standing_team}</th>
                      <th className="px-4 py-5 text-[12px] font-black uppercase text-center w-14 bg-white/5">{uz.standing_p}</th>
                      <th className="px-4 py-5 text-[12px] font-black uppercase text-center w-14 text-emerald-400 border-x border-white/5">{uz.standing_w}</th>
                      <th className="px-4 py-5 text-[12px] font-black uppercase text-center w-14 text-amber-400">{uz.standing_d}</th>
                      <th className="px-4 py-5 text-[12px] font-black uppercase text-center w-14 text-rose-400 border-x border-white/5">{uz.standing_l}</th>
                      <th className="px-4 py-5 text-[11px] font-black uppercase text-center w-14">{uz.standing_gf}</th>
                      <th className="px-4 py-5 text-[11px] font-black uppercase text-center w-14 border-x border-white/5">{uz.standing_ga}</th>
                      <th className="px-4 py-5 text-[11px] font-black uppercase text-center w-16">{uz.standing_gd}</th>
                      <th className="px-8 py-5 text-[13px] font-black uppercase text-center bg-[#d4af37] text-[#0a1a2f] w-32 italic-font">{uz.standing_pts}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {groupStandings.map((entry, index) => {
                      const team = currentTournament.teams.find(t => t.id === entry.teamId);
                      const isTop2 = index < 2;
                      return (
                        <tr key={entry.teamId} className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-all ${isTop2 ? 'bg-[#8a1538]/5' : ''}`}>
                          <td className="px-6 py-5 text-center border-r border-slate-100 dark:border-slate-800">
                            <span className={`inline-flex w-10 h-10 items-center justify-center rounded-xl font-black text-sm ${isTop2 ? 'bg-[#8a1538] text-[#d4af37] shadow-lg' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'}`}>
                              {index + 1}
                            </span>
                          </td>
                          <td className="px-6 py-5 font-black text-base dark:text-white uppercase tracking-tight">
                            {team?.name}
                          </td>
                          <td className="px-4 py-5 text-center text-sm font-black text-slate-900 dark:text-slate-100 bg-slate-50/50 dark:bg-slate-800/20">{entry.played}</td>
                          <td className="px-4 py-5 text-center text-base font-black text-emerald-600 dark:text-emerald-400 border-x border-slate-100 dark:border-slate-800">{entry.wins}</td>
                          <td className="px-4 py-5 text-center text-base font-black text-amber-500">{entry.draws}</td>
                          <td className="px-4 py-5 text-center text-base font-black text-rose-600 border-x border-slate-100 dark:border-slate-800">{entry.losses}</td>
                          <td className="px-4 py-5 text-center text-sm font-bold text-slate-500">{entry.gf}</td>
                          <td className="px-4 py-5 text-center text-sm font-bold text-slate-500 border-x border-slate-100 dark:border-slate-800">{entry.ga}</td>
                          <td className={`px-4 py-5 text-center text-sm font-black ${entry.gd > 0 ? 'text-blue-600' : entry.gd < 0 ? 'text-rose-600' : 'text-slate-400'}`}>
                            {entry.gd > 0 ? `+${entry.gd}` : entry.gd}
                          </td>
                          <td className="px-8 py-5 text-center bg-[#d4af37]/15 dark:bg-[#d4af37]/5">
                            <span className="font-black text-[#0a1a2f] dark:text-[#d4af37] text-4xl italic-font leading-none">{entry.pts}</span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Matchday Results UI */}
              <div className="space-y-12 no-print">
                 <div className="flex items-center space-x-3 text-[12px] font-black text-[#8a1538] dark:text-[#d4af37] uppercase tracking-[0.5em] ml-4">
                   <Zap className="w-5 h-5 fill-current" />
                   <span>{uz.matchday_results}</span>
                 </div>
                 
                 <div className="grid grid-cols-1 gap-16">
                    {sortedRounds.map(roundNum => (
                      <div key={roundNum} className="space-y-8 page-break-inside-avoid">
                        <div className="relative">
                          <div className="absolute inset-0 flex items-center" aria-hidden="true">
                            <div className="w-full border-t-2 border-slate-200 dark:border-slate-800"></div>
                          </div>
                          <div className="relative flex justify-start">
                            <span className="bg-[#8a1538] dark:bg-[#d4af37] text-white dark:text-[#0a1a2f] pr-10 pl-6 py-3 rounded-r-full text-xl font-black uppercase italic-font shadow-xl flex items-center space-x-3">
                              <Calendar className="w-5 h-5" />
                              <span>{roundNum}-{uz.matchday}</span>
                            </span>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 px-2">
                          {roundsMap[roundNum].map(m => {
                            const ht = currentTournament.teams.find(t => t.id === m.homeTeamId);
                            const at = currentTournament.teams.find(t => t.id === m.awayTeamId);
                            const isPlayed = m.status === MatchStatus.PLAYED;
                            return (
                              <div key={m.id} className="fifa-card rounded-[2rem] p-8 flex flex-col items-center group broadcast-shadow border-t-8 border-t-[#0a1a2f] dark:border-t-white/10 hover:border-t-[#8a1538] dark:hover:border-t-[#d4af37] transition-all duration-300">
                                <div className="w-full flex items-center justify-between gap-4 mb-8 min-h-[6rem]">
                                   <div className="flex-1 text-center py-2">
                                      <span className="block font-black text-[11px] dark:text-white uppercase tracking-tight leading-tight line-clamp-3 break-words min-h-[3rem] flex items-center justify-center">
                                        {ht?.name}
                                      </span>
                                   </div>
                                   
                                   <div className="flex flex-col items-center justify-center shrink-0">
                                      <div className={`px-4 py-3 rounded-2xl font-black text-3xl italic-font tracking-tighter shadow-2xl transition-all min-w-[95px] text-center ${isPlayed ? 'bg-[#8a1538] text-[#d4af37] scale-105' : 'bg-slate-100 text-slate-300 dark:bg-slate-800 dark:text-slate-700'}`}>
                                        {isPlayed ? `${m.homeScore}:${m.awayScore}` : 'VS'}
                                      </div>
                                   </div>

                                   <div className="flex-1 text-center py-2">
                                      <span className="block font-black text-[11px] dark:text-white uppercase tracking-tight leading-tight line-clamp-3 break-words min-h-[3rem] flex items-center justify-center">
                                        {at?.name}
                                      </span>
                                   </div>
                                </div>

                                <div className="w-full flex justify-around items-center border-t border-slate-100 dark:border-slate-800 pt-6">
                                   <div className="flex items-center space-x-2 text-[10px] font-black text-[#8a1538] dark:text-[#d4af37] uppercase tracking-widest bg-slate-50 dark:bg-slate-900/50 px-3 py-1.5 rounded-full">
                                     <Calendar className="w-3.5 h-3.5" />
                                     <span>{formatDate(m.date)}</span>
                                   </div>
                                   <div className="flex items-center space-x-2 text-[10px] font-black text-slate-500 uppercase tracking-widest bg-slate-50 dark:bg-slate-900/50 px-3 py-1.5 rounded-full">
                                     <Clock className="w-3.5 h-3.5" />
                                     <span>{m.time}</span>
                                   </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                 </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};


import React from 'react';
import { useTournament } from '../context/TournamentContext';
import { uz } from '../translations';
import { calculateStandings } from '../utils/scheduler';
import { Shield, Activity, Zap, Star } from 'lucide-react';
import { MatchStatus } from '../types';

export const GroupsOverview: React.FC = () => {
  const { state } = useTournament();
  const currentTournament = state.tournaments.find(t => t.id === state.currentTournamentId);

  if (!currentTournament) return <div className="p-8 text-center text-gray-500 italic-font uppercase">{uz.not_found}</div>;

  return (
    <div className="space-y-12 animate-fifa pb-24">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b-4 border-[#8a1538] pb-10">
        <div>
          <h1 className="text-5xl font-black dark:text-white uppercase tracking-tighter italic-font">
            {uz.groups} <span className="text-[#8a1538] dark:text-[#d4af37] underline decoration-[#d4af37]/30">{uz.monitoring}</span>
          </h1>
          <p className="text-gray-400 text-[10px] font-black uppercase tracking-[0.3em] mt-3 flex items-center">
            <Activity className="w-4 h-4 mr-3 text-emerald-500" /> {uz.realtime_stats}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {currentTournament.groups.map((group) => {
          const groupMatches = currentTournament.matches.filter(m => m.groupName === group.name);
          const groupStandings = calculateStandings(groupMatches, group.teams);
          const playedCount = groupMatches.filter(m => m.status === MatchStatus.PLAYED).length;
          const progress = groupMatches.length > 0 ? (playedCount / groupMatches.length) * 100 : 0;

          return (
            <div key={group.id} className="fifa-card rounded-[2.5rem] broadcast-shadow overflow-hidden flex flex-col group/card hover:border-[#8a1538]/30 transition-all border border-gray-100 dark:border-gray-800">
              <div className="p-8">
                <div className="flex justify-between items-center mb-10">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-[#8a1538] rounded-2xl flex items-center justify-center shadow-2xl">
                      <Shield className="w-6 h-6 text-[#d4af37]" />
                    </div>
                    <div>
                      <h2 className="text-3xl font-black dark:text-white uppercase tracking-tighter italic-font leading-none">{group.name}</h2>
                      <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mt-1">Guruh bosqichi</p>
                    </div>
                  </div>
                  <div className="bg-red-50 dark:bg-red-950/30 px-5 py-2 rounded-xl border border-red-100 dark:border-red-900/50">
                     <p className="text-[11px] font-black text-[#8a1538] dark:text-[#d4af37]">{Math.round(progress)}% {uz.ready}</p>
                  </div>
                </div>

                <div className="space-y-2 mb-10">
                  <div className="flex items-center text-[9px] font-black text-gray-400 uppercase tracking-widest px-4 mb-3">
                    <span className="w-8 text-center">№</span>
                    <span className="flex-1 ml-4">{uz.standing_team}</span>
                    <span className="w-10 text-center">{uz.standing_p}</span>
                    <span className="w-16 text-center text-[#8a1538] dark:text-[#d4af37]">{uz.standing_pts}</span>
                  </div>
                  {groupStandings.map((entry, idx) => {
                    const team = currentTournament.teams.find(t => t.id === entry.teamId);
                    return (
                      <div key={entry.teamId} className="flex items-center bg-gray-50 dark:bg-[#0a1a2f] p-4 rounded-xl border border-transparent hover:border-[#8a1538]/20 transition-all">
                        <span className={`w-8 h-8 flex items-center justify-center rounded-lg text-[11px] font-black ${idx < 2 ? 'bg-[#8a1538] text-[#d4af37] shadow-lg' : 'bg-gray-200 dark:bg-gray-800 text-gray-400'}`}>
                          {idx + 1}
                        </span>
                        <span className="flex-1 ml-4 font-black text-[13px] dark:text-gray-200 uppercase truncate tracking-tight">{team?.name}</span>
                        <span className="w-10 text-center text-xs font-bold text-gray-400 italic">{entry.played}</span>
                        <span className="w-16 text-center text-xl font-black dark:text-white italic-font leading-none">{entry.pts}</span>
                      </div>
                    );
                  })}
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between text-[10px] font-black text-gray-400 uppercase tracking-widest border-b-2 border-gray-50 dark:border-gray-900 pb-3">
                    <div className="flex items-center">
                      <Zap className="w-4 h-4 text-amber-500 fill-amber-500 mr-2" />
                      <span>{uz.last_results}</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 gap-3">
                    {groupMatches.filter(m => m.status === MatchStatus.PLAYED).slice(-2).map(m => {
                      const ht = currentTournament.teams.find(t => t.id === m.homeTeamId);
                      const at = currentTournament.teams.find(t => t.id === m.awayTeamId);
                      return (
                        <div key={m.id} className="flex items-center justify-between bg-white dark:bg-[#0f2238] border border-gray-100 dark:border-gray-800 p-3 rounded-2xl shadow-sm">
                          <span className="flex-1 text-right truncate pr-3 text-[11px] font-black dark:text-gray-400 uppercase tracking-tight">{ht?.name}</span>
                          <span className="bg-[#0a1a2f] text-[#d4af37] px-4 py-2 rounded-xl min-w-[55px] text-center font-black text-sm italic-font">{m.homeScore}:{m.awayScore}</span>
                          <span className="flex-1 text-left truncate pl-3 text-[11px] font-black dark:text-gray-400 uppercase tracking-tight">{at?.name}</span>
                        </div>
                      );
                    })}
                    {groupMatches.filter(m => m.status === MatchStatus.PLAYED).length === 0 && (
                       <p className="text-center text-[10px] font-black text-gray-300 uppercase py-6 italic">{uz.no_matches_yet}</p>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="mt-auto bg-gray-50 dark:bg-[#0a1a2f] p-6 border-t border-gray-100 dark:border-gray-800">
                <div className="w-full h-2.5 bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-[#8a1538] shadow-[0_0_15px_rgba(138,21,56,0.6)] transition-all duration-1000" 
                    style={{ width: `${progress}%` }}
                  ></div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};


import React, { useState } from 'react';
import { useTournament } from '../context/TournamentContext';
import { uz } from '../translations';
import { Trophy, Plus, Calendar, Clock, Trash2, CheckCircle2, X, Globe } from 'lucide-react';
import { MatchStatus, Match } from '../types';

export const Playoffs: React.FC = () => {
  const { state, addMatch, updateMatch, deleteMatch } = useTournament();
  const currentTournament = state.tournaments.find(t => t.id === state.currentTournamentId);
  const isAdmin = state.isAdmin;
  
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingMatchId, setEditingMatchId] = useState<string | null>(null);
  const [scores, setScores] = useState({ home: 0, away: 0 });
  const [newMatch, setNewMatch] = useState({
    homeTeamId: '',
    awayTeamId: '',
    roundName: uz.playoff_round_16,
    date: new Date().toISOString().split('T')[0],
    time: '20:00'
  });

  if (!currentTournament) return (
    <div className="flex flex-col items-center justify-center py-20 text-center animate-fifa">
      <Globe className="w-20 h-20 text-slate-200 dark:text-slate-800 mb-6" />
      <h2 className="text-xl font-black dark:text-white text-slate-400 uppercase tracking-tight italic-font">{uz.not_found}</h2>
    </div>
  );

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    const [year, month, day] = dateStr.split('-');
    return `${day}.${month}.${year}`;
  };

  const playoffMatches = currentTournament.matches.filter(m => m.isPlayoff);
  const rounds = [uz.playoff_round_16, uz.playoff_quarter, uz.playoff_semi, uz.playoff_final];

  const handleCreatePlayoffMatch = () => {
    if (!newMatch.homeTeamId || !newMatch.awayTeamId) return;

    const match: Match = {
      id: crypto.randomUUID(),
      homeTeamId: newMatch.homeTeamId,
      awayTeamId: newMatch.awayTeamId,
      round: 99,
      date: newMatch.date,
      time: newMatch.time,
      status: MatchStatus.PENDING,
      isPlayoff: true,
      playoffRoundName: newMatch.roundName
    };
    addMatch(currentTournament.id, match);
    setShowAddModal(false);
  };

  const handleSaveScore = (matchId: string) => {
    const match = playoffMatches.find(m => m.id === matchId);
    if (!match) return;
    
    updateMatch(currentTournament.id, {
      ...match,
      homeScore: scores.home,
      awayScore: scores.away,
      status: MatchStatus.PLAYED
    });
    setEditingMatchId(null);
  };

  const MatchCard: React.FC<{ match: Match }> = ({ match }) => {
    const ht = currentTournament.teams.find(t => t.id === match.homeTeamId);
    const at = currentTournament.teams.find(t => t.id === match.awayTeamId);
    const isPlayed = match.status === MatchStatus.PLAYED;
    const isEditing = editingMatchId === match.id;

    return (
      <div className="fifa-card rounded-[2rem] p-8 w-full max-w-[320px] broadcast-shadow border-t-8 border-t-[#0a1a2f] animate-fifa">
        <div className="flex justify-between items-center mb-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">
           <div className="flex items-center space-x-2">
             <Calendar className="w-3.5 h-3.5 text-[#8a1538]" />
             <span>{formatDate(match.date)}</span>
           </div>
           {isAdmin && (
            <button onClick={() => deleteMatch(currentTournament.id, match.id)} className="text-slate-200 hover:text-red-700 transition-colors">
              <Trash2 className="w-4 h-4" />
            </button>
           )}
        </div>

        <div className="space-y-3 mb-6">
           <div className={`flex items-center justify-between px-5 py-4 rounded-xl min-h-[4.5rem] ${isPlayed && (match.homeScore || 0) > (match.awayScore || 0) ? 'bg-[#8a1538] text-[#d4af37] shadow-xl' : 'bg-slate-50 dark:bg-[#0a1a2f]'}`}>
              <span className="font-black text-[12px] uppercase break-words flex-1 pr-4 line-clamp-3">{ht?.name || '???'}</span>
              {isEditing && isAdmin ? (
                <input type="number" value={scores.home} onChange={e => setScores({...scores, home: parseInt(e.target.value) || 0})} className="w-12 h-10 text-center bg-white dark:bg-[#0f2238] rounded-xl border-2 border-[#d4af37] font-black text-lg outline-none" />
              ) : (
                <span className={`font-black text-2xl italic-font shrink-0 ${isPlayed ? '' : 'text-slate-300'}`}>{isPlayed ? match.homeScore : '-'}</span>
              )}
           </div>

           <div className={`flex items-center justify-between px-5 py-4 rounded-xl min-h-[4.5rem] ${isPlayed && (match.awayScore || 0) > (match.homeScore || 0) ? 'bg-[#8a1538] text-[#d4af37] shadow-xl' : 'bg-slate-50 dark:bg-[#0a1a2f]'}`}>
              <span className="font-black text-[12px] uppercase break-words flex-1 pr-4 line-clamp-3">{at?.name || '???'}</span>
              {isEditing && isAdmin ? (
                <input type="number" value={scores.away} onChange={e => setScores({...scores, away: parseInt(e.target.value) || 0})} className="w-12 h-10 text-center bg-white dark:bg-[#0f2238] rounded-xl border-2 border-[#d4af37] font-black text-lg outline-none" />
              ) : (
                <span className={`font-black text-2xl italic-font shrink-0 ${isPlayed ? '' : 'text-slate-300'}`}>{isPlayed ? match.awayScore : '-'}</span>
              )}
           </div>
        </div>

        {isAdmin && (
          <div className="flex justify-center pt-4 border-t border-slate-100 dark:border-slate-800">
            {isEditing ? (
              <button onClick={() => handleSaveScore(match.id)} className="text-emerald-600 font-black text-[11px] uppercase tracking-widest flex items-center">
                <CheckCircle2 className="w-4 h-4 mr-2" /> {uz.save}
              </button>
            ) : (
              <button onClick={() => {setEditingMatchId(match.id); setScores({home: match.homeScore || 0, away: match.awayScore || 0})}} className="text-[#8a1538] dark:text-[#d4af37] text-[10px] font-black uppercase tracking-widest hover:underline">
                {uz.set_score}
              </button>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-12 animate-fifa pb-24">
      {/* Header Banner */}
      <div className="bg-[#8a1538] p-10 rounded-[2rem] shadow-2xl border-b-8 border-[#d4af37] flex flex-col md:flex-row justify-between items-center gap-8">
        <div>
          <h1 className="text-5xl font-black text-white uppercase tracking-tighter italic-font leading-none">{uz.playoffs}</h1>
          <p className="text-[10px] font-black text-[#d4af37] uppercase tracking-[0.4em] mt-2">{uz.knockout_stage}</p>
        </div>
        {isAdmin && (
          <button onClick={() => setShowAddModal(true)} className="fifa-btn-gold px-10 py-5 rounded-xl text-[11px] font-black uppercase tracking-widest shadow-2xl hover:scale-105 active:scale-95 transition-all">
            {uz.add_match}
          </button>
        )}
      </div>

      <div className="overflow-x-auto pb-10 custom-scrollbar">
        <div className="min-w-[1200px] flex justify-between gap-10 p-4">
          {rounds.map((roundName) => (
            <div key={roundName} className="flex-1 space-y-10">
              <div className="text-center">
                <div className="inline-flex items-center px-8 py-3 bg-[#0a1a2f] dark:bg-white text-white dark:text-[#0a1a2f] text-[12px] font-black uppercase tracking-[0.3em] rounded-xl shadow-2xl italic-font">
                  {roundName}
                </div>
              </div>

              <div className="flex flex-col justify-around min-h-[500px] space-y-12 py-6 relative">
                {playoffMatches.filter(m => m.playoffRoundName === roundName).map(match => (
                  <div key={match.id} className="flex items-center justify-center">
                     <MatchCard match={match} />
                  </div>
                ))}
                {playoffMatches.filter(m => m.playoffRoundName === roundName).length === 0 && (
                  <div className="text-center py-20 border-4 border-dashed border-slate-100 dark:border-slate-800 rounded-[3rem] opacity-20">
                    <Trophy className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">KUTILMOQDA</p>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-[#0a1a2f]/95 backdrop-blur-md flex items-center justify-center z-[100] p-4">
          <div className="bg-white dark:bg-[#0f2238] w-full max-w-lg p-12 rounded-[2.5rem] shadow-2xl border-t-8 border-[#8a1538] animate-fifa relative">
            <button onClick={() => setShowAddModal(false)} className="absolute top-8 right-8 text-slate-400 hover:text-slate-900 transition-colors">
              <X className="w-8 h-8" />
            </button>
            <h3 className="text-4xl font-black dark:text-white uppercase italic-font mb-10">{uz.new_fixture}</h3>
            
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-3">
                 {rounds.map(r => (
                   <button 
                     key={r} 
                     onClick={() => setNewMatch({...newMatch, roundName: r})}
                     className={`py-4 rounded-xl text-[10px] font-black uppercase tracking-widest border-2 transition-all ${newMatch.roundName === r ? 'bg-[#8a1538] border-[#8a1538] text-[#d4af37]' : 'border-slate-100 dark:border-slate-800 text-slate-400 hover:border-[#d4af37]'}`}
                   >
                     {r}
                   </button>
                 ))}
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <select value={newMatch.homeTeamId} onChange={e => setNewMatch({...newMatch, homeTeamId: e.target.value})} className="px-5 py-4 rounded-xl bg-slate-50 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-2 border-slate-100 dark:border-slate-800 focus:border-[#8a1538]">
                  <option value="">{uz.home}...</option>
                  {currentTournament.teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
                <select value={newMatch.awayTeamId} onChange={e => setNewMatch({...newMatch, awayTeamId: e.target.value})} className="px-5 py-4 rounded-xl bg-slate-50 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-2 border-slate-100 dark:border-slate-800 focus:border-[#8a1538]">
                  <option value="">{uz.away}...</option>
                  {currentTournament.teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <input type="date" value={newMatch.date} onChange={e => setNewMatch({...newMatch, date: e.target.value})} className="px-5 py-4 rounded-xl bg-slate-50 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-2 border-slate-100 dark:border-slate-800 focus:border-[#8a1538]" />
                <input type="time" value={newMatch.time} onChange={e => setNewMatch({...newMatch, time: e.target.value})} className="px-5 py-4 rounded-xl bg-slate-50 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-2 border-slate-100 dark:border-slate-800 focus:border-[#8a1538]" />
              </div>

              <button onClick={handleCreatePlayoffMatch} className="w-full py-5 bg-[#8a1538] text-white rounded-xl font-black uppercase text-[12px] tracking-widest shadow-2xl hover:bg-[#5e0e26] transition-all">
                {uz.schedule_match}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

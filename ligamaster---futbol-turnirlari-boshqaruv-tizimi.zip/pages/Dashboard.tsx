
import React from 'react';
import { useTournament } from '../context/TournamentContext';
import { uz } from '../translations';
import { Trophy, Users, Calendar, ChevronRight, Plus, Activity, Star, TrendingUp, Zap, Globe } from 'lucide-react';

const StatCard: React.FC<{ icon: React.ReactNode; label: string; value: string | number; color: string; trend?: string }> = ({
  icon, label, value, color, trend
}) => (
  <div className="bg-white dark:bg-[#0f2238] p-8 rounded-[2.5rem] shadow-xl border-b-4 border-[#8a1538] flex flex-col justify-between hover:scale-[1.02] transition-all duration-500 group relative overflow-hidden animate-fifa">
    <div className={`absolute -right-6 -top-6 w-32 h-32 rounded-full ${color} opacity-[0.05] group-hover:scale-150 transition-transform duration-1000`}></div>
    
    <div className="flex justify-between items-start relative z-10">
      <div className={`p-4 rounded-2xl ${color} bg-opacity-10 dark:bg-opacity-20`}>
        {React.cloneElement(icon as React.ReactElement, { className: `w-8 h-8 ${color.replace('bg-', 'text-')}` })}
      </div>
      {trend && (
        <span className="flex items-center text-[9px] font-black text-emerald-500 bg-emerald-50 dark:bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-500/10 uppercase tracking-widest">
           {trend}
        </span>
      )}
    </div>
    
    <div className="mt-10 relative z-10">
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{label}</p>
      <p className="text-5xl font-black dark:text-white italic-font leading-none tracking-tighter">{value}</p>
    </div>
  </div>
);

export const Dashboard: React.FC<{ setView: (v: string) => void }> = ({ setView }) => {
  const { state } = useTournament();
  const isAdmin = state.isAdmin;
  
  const tournamentsCount = state.tournaments.length;
  const teamsCount = state.tournaments.reduce((acc, t) => acc + t.teams.length, 0);
  const matchesCount = state.tournaments.reduce((acc, t) => acc + t.matches.length, 0);

  return (
    <div className="space-y-12 pb-20 max-w-[1400px] mx-auto animate-fifa">
      {/* Welcome Banner */}
      <div className="relative bg-[#8a1538] rounded-[3.5rem] p-12 lg:p-16 overflow-hidden shadow-2xl border-b-8 border-[#d4af37]">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-white opacity-5 rotate-12 -translate-y-10"></div>
        <div className="absolute -left-20 -bottom-20 w-[400px] h-[400px] bg-[#d4af37] opacity-[0.05] rounded-full blur-[100px]"></div>
        
        <div className="relative z-10 flex flex-col lg:flex-row justify-between items-center gap-12">
          <div className="text-center lg:text-left max-w-2xl">
            <div className="inline-flex items-center space-x-2 px-5 py-2 bg-black/20 text-[#d4af37] rounded-full text-[10px] font-black uppercase tracking-widest mb-8 border border-white/10">
              <Zap className="w-3 h-3 fill-current" />
              <span>RASMIY TURNIR HUBI</span>
            </div>
            <h1 className="text-6xl lg:text-8xl font-black text-white uppercase tracking-tighter italic-font leading-[0.85] mb-8">
              {uz.welcome} <br/> <span className="text-[#d4af37]">LIGAMASTER</span>
            </h1>
            <p className="text-slate-200 text-lg lg:text-xl font-medium leading-relaxed italic opacity-80">
              {isAdmin 
                ? "Turnirlarni boshqarish, jadvallarni shakllantirish va natijalarni real-vaqtda kuzatish boshqaruv markazi." 
                : "Ligalar holati, jamoalar reytingi va o'yinlar taqvimi barchasi bir joyda."}
            </p>
          </div>
          
          {isAdmin && (
            <button 
              onClick={() => setView('tournaments')}
              className="fifa-btn-gold group flex items-center space-x-4 px-12 py-8 rounded-[2.5rem] font-black text-sm uppercase tracking-[0.15em] shadow-2xl transition-all hover:scale-105 active:scale-95"
            >
              <div className="bg-black/10 p-2.5 rounded-xl group-hover:rotate-90 transition-all">
                <Plus className="w-6 h-6" />
              </div>
              <span>{uz.create_tournament}</span>
            </button>
          )}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <StatCard 
          icon={<Trophy />} 
          label={uz.active_tournaments} 
          value={tournamentsCount} 
          color="bg-[#d4af37]" 
          trend="ONLINE"
        />
        <StatCard 
          icon={<Users />} 
          label="Barcha Jamoalar" 
          value={teamsCount} 
          color="bg-blue-500" 
          trend="FAOLLIK"
        />
        <StatCard 
          icon={<Calendar />} 
          label="O'yinlar" 
          value={matchesCount} 
          color="bg-red-500" 
        />
      </div>

      {/* Recent Tournaments */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-10">
        <div className="xl:col-span-2 bg-white dark:bg-[#0f2238] p-10 rounded-[3.5rem] shadow-xl border-b-4 border-[#8a1538]">
          <div className="flex justify-between items-center mb-12">
            <div className="flex items-center space-x-4">
               <div className="w-14 h-14 bg-[#8a1538] rounded-2xl flex items-center justify-center shadow-xl">
                 <Globe className="w-7 h-7 text-[#d4af37]" />
               </div>
               <div>
                  <h3 className="text-3xl font-black dark:text-white uppercase tracking-tighter italic-font leading-none">Turnirlar Arvixi</h3>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">So'nggi faoliyatlar</p>
               </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {state.tournaments.slice(0, 4).map(t => (
              <div 
                key={t.id} 
                onClick={() => setView(isAdmin ? 'tournaments' : 'standings')}
                className="group/card flex items-center justify-between p-6 bg-slate-50 dark:bg-[#0a1a2f] rounded-[2rem] hover:bg-white dark:hover:bg-[#13283f] transition-all cursor-pointer border-l-4 border-[#8a1538] shadow-sm"
              >
                <div className="flex items-center space-x-6">
                  <div className="w-12 h-12 bg-white dark:bg-[#0f2238] rounded-xl flex items-center justify-center border border-slate-100 dark:border-slate-800">
                    <Trophy className="w-6 h-6 text-[#d4af37]" />
                  </div>
                  <div>
                    <h4 className="font-black dark:text-white text-md uppercase tracking-tighter leading-tight">{t.name}</h4>
                    <div className="flex items-center space-x-3 mt-1">
                      <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{t.teams.length} Jamoa</span>
                      <span className="text-[8px] font-black text-emerald-500 uppercase tracking-widest">Aktiv</span>
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-300 group-hover/card:text-[#8a1538] transition-colors" />
              </div>
            ))}
            {state.tournaments.length === 0 && (
              <p className="col-span-full text-center py-10 text-slate-400 font-black uppercase text-[10px] tracking-widest italic">Hech qanday turnir yaratilmagan</p>
            )}
          </div>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-8">
           <div className="bg-[#0a1a2f] p-10 rounded-[3rem] text-white shadow-2xl relative overflow-hidden group border-b-8 border-[#d4af37]">
              <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:rotate-12 transition-transform duration-700">
                <Activity className="w-32 h-32" />
              </div>
              <h4 className="text-2xl font-black uppercase italic-font mb-4 text-[#d4af37]">PRO LIVE</h4>
              <p className="text-slate-400 text-sm font-medium leading-relaxed mb-10">Barcha turnir ko'rsatkichlari real vaqt rejimida yangilab boriladi.</p>
              <button 
                onClick={() => setView('matches')}
                className="w-full py-5 bg-[#8a1538] text-white rounded-xl font-black text-xs uppercase tracking-widest transition-all hover:bg-[#a11a43]"
              >
                {uz.matches}
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};

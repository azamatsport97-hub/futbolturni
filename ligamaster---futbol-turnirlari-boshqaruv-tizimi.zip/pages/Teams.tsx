
import React, { useState, useEffect } from 'react';
import { useTournament } from '../context/TournamentContext';
import { uz } from '../translations';
import { Trash2, Plus, Layers, AlertTriangle, Users, X, FolderPlus } from 'lucide-react';

export const Teams: React.FC = () => {
  const { state, addTeamsToGroup, deleteTeam, addGroup, deleteGroup } = useTournament();
  const currentTournament = state.tournaments.find(t => t.id === state.currentTournamentId);
  
  const [newTeamName, setNewTeamName] = useState('');
  const [selectedGroupId, setSelectedGroupId] = useState('');
  const [newGroupName, setNewGroupName] = useState('');
  const [showGroupModal, setShowGroupModal] = useState(false);
  
  const [confirmModal, setConfirmModal] = useState<{
    show: boolean;
    type: 'team' | 'group';
    id: string;
    name: string;
  }>({ show: false, type: 'team', id: '', name: '' });

  // Guruhlar ro'yxati o'zgarganda tanlangan guruhni tekshirish va yangilash
  // Bu jamoa qo'shilmay qolish muammosini hal qiladi
  useEffect(() => {
    if (currentTournament && currentTournament.groups.length > 0) {
      const groupExists = currentTournament.groups.some(g => g.id === selectedGroupId);
      if (!selectedGroupId || !groupExists) {
        setSelectedGroupId(currentTournament.groups[0].id);
      }
    } else {
      setSelectedGroupId('');
    }
  }, [currentTournament?.groups, selectedGroupId]);

  if (!currentTournament) return (
    <div className="p-20 text-center animate-fifa">
      <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
      <h2 className="text-xl font-black uppercase text-slate-400 italic-font">{uz.not_found}</h2>
    </div>
  );

  const handleAddTeam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeamName.trim()) {
      alert("Iltimos, jamoa nomini kiriting!");
      return;
    }
    
    if (!selectedGroupId) {
      alert("Iltimos, avval guruh yarating!");
      return;
    }

    const team = { 
      id: crypto.randomUUID(), 
      name: newTeamName.trim(), 
      groupId: selectedGroupId 
    };
    
    addTeamsToGroup(currentTournament.id, selectedGroupId, [team]);
    setNewTeamName('');
  };

  const handleAddGroup = () => {
    if (!newGroupName.trim()) return;
    addGroup(currentTournament.id, newGroupName.trim());
    setNewGroupName('');
    setShowGroupModal(false);
  };

  const executeDelete = () => {
    if (confirmModal.type === 'team') {
      deleteTeam(currentTournament.id, confirmModal.id);
    } else {
      deleteGroup(currentTournament.id, confirmModal.id);
    }
    setConfirmModal({ ...confirmModal, show: false });
  };

  return (
    <div className="space-y-12 animate-fifa pb-24">
      <div className="flex flex-col md:flex-row justify-between items-center gap-6 bg-[#8a1538] p-10 rounded-[2rem] shadow-2xl border-b-8 border-[#d4af37]">
        <div className="relative z-10">
          <h1 className="text-4xl font-black text-white uppercase tracking-tighter italic-font leading-none">{uz.registered_delegations}</h1>
          <p className="text-[10px] font-black text-[#d4af37] uppercase tracking-widest mt-2">{uz.manage_teams_groups}</p>
        </div>
        <button 
          onClick={() => setShowGroupModal(true)}
          className="fifa-btn-gold px-8 py-4 rounded-xl font-black text-[11px] uppercase tracking-widest shadow-xl transition-all hover:scale-105 active:scale-95 flex items-center space-x-2"
        >
          <FolderPlus className="w-4 h-4" />
          <span>{uz.add_group}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-10">
        <div className="lg:col-span-1">
          <div className="fifa-card p-10 rounded-[2rem] broadcast-shadow border-t-8 border-t-[#8a1538] sticky top-32">
            <h3 className="text-xl font-black dark:text-white uppercase tracking-tight mb-8">{uz.add_team}</h3>
            <form onSubmit={handleAddTeam} className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{uz.select_group}</label>
                <select 
                  value={selectedGroupId}
                  onChange={(e) => setSelectedGroupId(e.target.value)}
                  className="w-full px-5 py-4 rounded-xl bg-slate-50 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-2 border-slate-100 dark:border-slate-800 focus:border-[#8a1538] cursor-pointer"
                >
                  {currentTournament.groups.length === 0 && <option value="">{uz.not_found}</option>}
                  {currentTournament.groups.map(g => (
                    <option key={g.id} value={g.id}>{g.name}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{uz.team_name}</label>
                <input 
                  type="text" 
                  value={newTeamName}
                  onChange={(e) => setNewTeamName(e.target.value)}
                  placeholder="Masalan: Paxtakor..."
                  className="w-full px-5 py-4 rounded-xl bg-slate-50 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-2 border-slate-100 dark:border-slate-800 focus:border-[#8a1538]"
                />
              </div>
              <button 
                type="submit" 
                className="w-full py-4 bg-[#8a1538] text-white rounded-xl font-black uppercase text-[11px] tracking-widest shadow-xl hover:bg-[#5e0e26] transition-all"
              >
                {uz.register_team}
              </button>
            </form>
          </div>
        </div>

        <div className="lg:col-span-3 space-y-12">
          {currentTournament.groups.map(group => (
            <div key={group.id} className="fifa-card p-10 rounded-[2rem] broadcast-shadow border-t-8 border-t-[#0a1a2f]">
              <div className="flex items-center justify-between mb-10 pb-6 border-b-2 border-slate-100 dark:border-slate-800">
                <div className="flex items-center space-x-6">
                  <span className="text-3xl font-black dark:text-white uppercase tracking-tighter italic-font">{group.name}</span>
                  <button 
                    onClick={() => setConfirmModal({ show: true, type: 'group', id: group.id, name: group.name })} 
                    className="p-2 text-red-200 hover:text-red-700 transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
                <div className="text-[10px] font-black text-[#d4af37] bg-[#0a1a2f] px-4 py-1.5 rounded-full uppercase tracking-widest">
                  {group.teams.length} jamoa
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {group.teams.map(tid => {
                  const team = currentTournament.teams.find(tm => tm.id === tid);
                  if (!team) return null;
                  return (
                    <div key={team.id} className="flex items-center justify-between p-6 bg-slate-50 dark:bg-[#0a1a2f] rounded-xl border-l-4 border-l-[#8a1538] hover:bg-white dark:hover:bg-[#13283f] transition-all group shadow-sm">
                      <span className="font-black dark:text-white text-md uppercase tracking-tight">{team.name}</span>
                      <button 
                        onClick={() => setConfirmModal({ show: true, type: 'team', id: team.id, name: team.name })} 
                        className="p-2 text-slate-200 hover:text-red-700 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  );
                })}
                {group.teams.length === 0 && (
                   <p className="col-span-full text-center py-6 text-slate-400 text-[10px] font-black uppercase tracking-widest italic">Hali jamoalar qo'shilmagan</p>
                )}
              </div>
            </div>
          ))}
          {currentTournament.groups.length === 0 && (
            <div className="text-center py-24 bg-slate-50 dark:bg-slate-900 rounded-[3rem] border-4 border-dashed border-slate-200 dark:border-slate-800">
               <Layers className="w-16 h-16 text-slate-300 mx-auto mb-4" />
               <p className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em]">Turnirda hali guruhlar yo'q. Avval guruh qo'shing.</p>
            </div>
          )}
        </div>
      </div>

      {showGroupModal && (
        <div className="fixed inset-0 bg-[#0a1a2f]/90 backdrop-blur-md flex items-center justify-center z-[200] p-4">
          <div className="bg-white dark:bg-[#0f2238] w-full max-w-md p-12 rounded-[2rem] shadow-2xl border-t-8 border-[#d4af37] animate-fifa relative">
            <button onClick={() => setShowGroupModal(false)} className="absolute top-8 right-8 text-slate-400 hover:text-slate-900 transition-colors">
              <X className="w-8 h-8" />
            </button>
            <div className="text-center mb-10">
              <div className="w-16 h-16 bg-[#8a1538] rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl">
                 <Plus className="w-8 h-8 text-[#d4af37]" />
              </div>
              <h3 className="text-3xl font-black dark:text-white uppercase tracking-tight italic-font">{uz.add_group}</h3>
            </div>
            <div className="space-y-6">
              <div className="space-y-2">
                 <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{uz.group_name}</label>
                 <input 
                   type="text" 
                   value={newGroupName}
                   onChange={(e) => setNewGroupName(e.target.value)}
                   placeholder="Masalan: B Guruhi..."
                   autoFocus
                   className="w-full px-5 py-4 rounded-xl bg-slate-50 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-2 border-slate-100 dark:border-slate-800 focus:border-[#8a1538]"
                 />
              </div>
              <button 
                onClick={handleAddGroup}
                className="w-full py-5 bg-[#8a1538] text-white rounded-xl font-black uppercase text-[12px] tracking-widest shadow-2xl hover:bg-[#5e0e26] transition-all"
              >
                {uz.save}
              </button>
            </div>
          </div>
        </div>
      )}

      {confirmModal.show && (
        <div className="fixed inset-0 bg-[#0a1a2f]/90 backdrop-blur-md flex items-center justify-center z-[250] p-4">
          <div className="bg-white dark:bg-[#0f2238] w-full max-sm p-12 rounded-[2rem] shadow-2xl text-center border-t-8 border-red-700 animate-fifa">
            <AlertTriangle className="w-16 h-16 text-red-700 mx-auto mb-6" />
            <h3 className="text-2xl font-black dark:text-white uppercase italic-font mb-4">{uz.confirm_removal}</h3>
            <p className="text-slate-500 text-sm mb-10 font-medium italic">"{confirmModal.name}" {uz.delete_warning}</p>
            <div className="grid grid-cols-2 gap-4">
              <button onClick={() => setConfirmModal({ ...confirmModal, show: false })} className="py-4 rounded-xl font-black text-[10px] uppercase tracking-widest text-slate-400 bg-slate-50 dark:bg-slate-800">{uz.cancel}</button>
              <button onClick={executeDelete} className="py-4 rounded-xl font-black text-[10px] uppercase tracking-widest text-white bg-red-700 shadow-xl">{uz.purge_data}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


import React, { useState } from 'react';
import { useTournament } from '../context/TournamentContext';
import { uz } from '../translations';
import { Trophy, Plus, Trash2, Edit2, Calendar, Users, MapPin, AlertTriangle, X } from 'lucide-react';

export const Tournaments: React.FC = () => {
  const { state, createTournament, updateTournament, selectTournament, deleteTournament } = useTournament();
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    startDate: '',
    endDate: ''
  });

  const formatDate = (dateStr: string) => {
    if (!dateStr) return uz.unknown;
    const [year, month, day] = dateStr.split('-');
    return `${day}.${month}.${year}`;
  };

  const handleOpenModal = (tournamentId?: string) => {
    if (tournamentId) {
      const t = state.tournaments.find(tourn => tourn.id === tournamentId);
      if (t) {
        setFormData({
          name: t.name,
          location: t.location || '',
          startDate: t.startDate || '',
          endDate: t.endDate || ''
        });
        setEditingId(tournamentId);
      }
    } else {
      setFormData({ name: '', location: '', startDate: '', endDate: '' });
      setEditingId(null);
    }
    setShowModal(true);
  };

  const handleSave = () => {
    if (!formData.name.trim()) {
      alert("Turnir nomini kiriting!");
      return;
    }
    
    if (editingId) {
      updateTournament(editingId, formData);
    } else {
      createTournament(formData);
    }
    
    setFormData({ name: '', location: '', startDate: '', endDate: '' });
    setEditingId(null);
    setShowModal(false);
  };

  const handleDelete = () => {
    if (confirmDeleteId) {
      deleteTournament(confirmDeleteId);
      setConfirmDeleteId(null);
    }
  };

  const tournamentToDelete = state.tournaments.find(t => t.id === confirmDeleteId);

  return (
    <div className="space-y-12 animate-fifa pb-24">
      <div className="flex flex-col md:flex-row justify-between items-center gap-6 bg-[#8a1538] p-10 rounded-[2rem] shadow-2xl border-b-8 border-[#d4af37]">
        <div className="relative z-10">
          <h1 className="text-4xl font-black text-white uppercase tracking-tighter italic-font leading-none">{uz.tournaments}</h1>
          <p className="text-[10px] font-black text-[#d4af37] uppercase tracking-widest mt-2">{uz.active_tournaments}</p>
        </div>
        <button 
          onClick={() => handleOpenModal()}
          className="fifa-btn-gold px-8 py-4 rounded-xl font-black text-[11px] uppercase tracking-widest shadow-xl transition-all hover:scale-105 active:scale-95 flex items-center space-x-2"
        >
          <Plus className="w-5 h-5" />
          <span>{uz.create_tournament}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {state.tournaments.map(t => (
          <div key={t.id} className="fifa-card p-8 rounded-[2rem] broadcast-shadow hover:scale-[1.02] transition-all group relative border border-gray-100 dark:border-gray-800">
            <div className="flex justify-between items-start mb-6">
              <div className={`p-5 rounded-2xl ${state.currentTournamentId === t.id ? 'bg-[#8a1538] text-[#d4af37] shadow-xl' : 'bg-gray-50 dark:bg-gray-900 text-gray-400'}`}>
                <Trophy className="w-10 h-10" />
              </div>
              <div className="flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button 
                  onClick={() => handleOpenModal(t.id)}
                  className="p-2 text-gray-300 hover:text-blue-600 transition-colors"
                  title={uz.edit}
                >
                  <Edit2 className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => setConfirmDeleteId(t.id)}
                  className="p-2 text-gray-300 hover:text-red-600 transition-colors"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <h3 className="text-2xl font-black dark:text-white uppercase tracking-tight italic-font mb-4">{t.name}</h3>
            
            <div className="space-y-3 mb-8 text-[11px] font-black uppercase tracking-widest text-gray-500 dark:text-gray-400">
               <div className="flex items-center">
                 <MapPin className="w-4 h-4 mr-3 text-[#8a1538] dark:text-[#d4af37]" />
                 {t.location || uz.unknown}
               </div>
               <div className="flex items-center">
                 <Calendar className="w-4 h-4 mr-3 text-[#8a1538] dark:text-[#d4af37]" />
                 {formatDate(t.startDate || '')} - {formatDate(t.endDate || '')}
               </div>
               <div className="flex items-center">
                 <Users className="w-4 h-4 mr-3 text-[#8a1538] dark:text-[#d4af37]" />
                 {t.teams.length} jamoa • {t.groups.length} guruh
               </div>
            </div>

            <button 
              onClick={() => selectTournament(t.id)}
              className={`w-full py-4 rounded-xl font-black uppercase text-[10px] tracking-[0.2em] transition-all shadow-md ${
                state.currentTournamentId === t.id 
                  ? 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 border border-emerald-200 cursor-default' 
                  : 'bg-[#0a1a2f] text-white hover:bg-[#8a1538]'
              }`}
            >
              {state.currentTournamentId === t.id ? uz.active_now : uz.select}
            </button>
          </div>
        ))}
        {state.tournaments.length === 0 && (
          <div className="col-span-full py-20 text-center bg-white dark:bg-[#0f2238] rounded-[3rem] border-4 border-dashed border-gray-100 dark:border-gray-800">
             <Trophy className="w-20 h-20 text-gray-200 mx-auto mb-6" />
             <p className="text-xl font-black uppercase text-gray-400 italic-font">{uz.not_found}</p>
          </div>
        )}
      </div>

      {/* Yaratish/Tahrirlash modali */}
      {showModal && (
        <div className="fixed inset-0 bg-[#0a1a2f]/90 backdrop-blur-md flex items-center justify-center z-[100] p-4">
          <div className="bg-white dark:bg-[#0f2238] w-full max-w-lg p-12 rounded-[2.5rem] shadow-2xl border-t-8 border-[#8a1538] animate-fifa relative">
            <button onClick={() => setShowModal(false)} className="absolute top-8 right-8 text-slate-400 hover:text-slate-900 transition-colors">
              <X className="w-8 h-8" />
            </button>
            <h3 className="text-3xl font-black dark:text-white uppercase tracking-tight italic-font mb-10">
              {editingId ? "Turnirni Tahrirlash" : uz.tournament_details}
            </h3>
            <div className="space-y-6">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{uz.tournament_name}</label>
                <input type="text" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} placeholder="Masalan: Maktab Ligasi 2025" className="w-full px-5 py-4 rounded-xl border-2 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-gray-100 dark:border-gray-800 focus:border-[#8a1538]" />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{uz.location}</label>
                <input type="text" value={formData.location} onChange={(e) => setFormData({ ...formData, location: e.target.value })} placeholder="Masalan: Paxtakor stadioni" className="w-full px-5 py-4 rounded-xl border-2 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-gray-100 dark:border-gray-800 focus:border-[#8a1538]" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{uz.start_date}</label>
                  <input type="date" value={formData.startDate} onChange={(e) => setFormData({ ...formData, startDate: e.target.value })} className="w-full px-5 py-4 rounded-xl border-2 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-gray-100 dark:border-gray-800 focus:border-[#8a1538]" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{uz.end_date}</label>
                  <input type="date" value={formData.endDate} onChange={(e) => setFormData({ ...formData, endDate: e.target.value })} className="w-full px-5 py-4 rounded-xl border-2 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-gray-100 dark:border-gray-800 focus:border-[#8a1538]" />
                </div>
              </div>
            </div>
            <div className="flex space-x-4 mt-12">
              <button onClick={() => setShowModal(false)} className="flex-1 py-4 rounded-xl font-black uppercase text-[10px] tracking-widest text-slate-400 bg-gray-50 dark:bg-gray-900 transition-all">{uz.cancel}</button>
              <button onClick={handleSave} className="flex-1 py-4 rounded-xl font-black uppercase text-[10px] tracking-widest text-white bg-[#8a1538] hover:bg-red-800 transition-all shadow-xl">{uz.save}</button>
            </div>
          </div>
        </div>
      )}

      {/* O'chirishni tasdiqlash modali */}
      {confirmDeleteId && (
        <div className="fixed inset-0 bg-[#0a1a2f]/90 backdrop-blur-md flex items-center justify-center z-[200] p-4">
          <div className="bg-white dark:bg-[#0f2238] w-full max-w-sm p-12 rounded-[2rem] shadow-2xl text-center border-t-8 border-red-700 animate-fifa">
            <AlertTriangle className="w-16 h-16 text-red-700 mx-auto mb-6" />
            <h3 className="text-2xl font-black dark:text-white uppercase italic-font mb-4">{uz.delete_confirm}</h3>
            <p className="text-gray-500 dark:text-gray-400 mb-10 text-sm">
              <span className="font-bold text-gray-900 dark:text-gray-100">"{tournamentToDelete?.name}"</span> ni o'chirishni xohlaysizmi? {uz.delete_warning}
            </p>
            <div className="grid grid-cols-2 gap-4">
              <button onClick={() => setConfirmDeleteId(null)} className="py-4 rounded-xl font-black uppercase text-[10px] tracking-widest text-gray-400 bg-gray-50 dark:bg-gray-800">{uz.no_keep}</button>
              <button onClick={handleDelete} className="py-4 rounded-xl font-black uppercase text-[10px] tracking-widest text-white bg-red-700 shadow-xl">{uz.yes_delete}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

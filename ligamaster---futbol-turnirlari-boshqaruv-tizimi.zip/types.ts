
export enum MatchStatus {
  PENDING = 'PENDING',
  PLAYED = 'PLAYED'
}

export interface Team {
  id: string;
  name: string;
  logo?: string;
  groupId: string;
}

export interface Match {
  id: string;
  homeTeamId: string;
  awayTeamId: string;
  homeScore?: number;
  awayScore?: number;
  date: string;
  time: string;
  status: MatchStatus;
  groupName?: string;
  round: number;
  isPlayoff: boolean;
  playoffRoundName?: string;
}

export interface Group {
  id: string;
  name: string;
  teams: string[]; // Team IDs
}

export interface Tournament {
  id: string;
  name: string;
  location?: string;
  startDate?: string;
  endDate?: string;
  logo?: string;
  isPremium: boolean;
  groups: Group[];
  matches: Match[];
  teams: Team[];
  createdAt: string;
}

export interface AppState {
  currentTournamentId: string | null;
  tournaments: Tournament[];
  isPremiumUser: boolean;
  isAdmin: boolean;
  theme: 'light' | 'dark';
  adminUsername?: string;
  adminPassword?: string;
}

export interface StandingEntry {
  teamId: string;
  played: number;
  wins: number;
  draws: number;
  losses: number;
  gf: number;
  ga: number;
  gd: number;
  pts: number;
}


import React, { useState } from 'react';
import { useTournament } from '../context/TournamentContext';
import { uz } from '../translations';
// Added missing import for ApiService
import { ApiService } from '../api';
import { 
  LayoutDashboard, 
  Trophy, 
  Users, 
  Table2, 
  CalendarDays, 
  Settings, 
  Menu,
  Moon,
  Sun,
  Layers,
  GitMerge,
  ShieldAlert,
  Eye,
  Lock,
  KeyRound,
  LogOut,
  User,
  Activity,
  Globe,
  Loader2,
  Database,
  Wifi,
  RefreshCw
} from 'lucide-react';

const SidebarItem: React.FC<{ 
  icon: React.ReactNode; 
  label: string; 
  active?: boolean; 
  onClick: () => void;
  disabled?: boolean;
}> = ({ icon, label, active, onClick, disabled }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    className={`w-full flex items-center justify-between px-6 py-4 rounded-xl transition-all duration-300 group ${
      active 
        ? 'bg-[#8a1538] text-white shadow-xl shadow-red-900/20' 
        : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800/50'
    } ${disabled ? 'opacity-30 cursor-not-allowed' : ''}`}
  >
    <div className="flex items-center space-x-4">
      <div className={`transition-colors ${active ? 'text-[#d4af37]' : 'text-slate-400 group-hover:text-[#8a1538]'}`}>
        {icon}
      </div>
      <span className="font-extrabold text-[11px] uppercase tracking-wider">{label}</span>
    </div>
    {active && <div className="w-1.5 h-1.5 bg-[#d4af37] rounded-full" />}
  </button>
);

export const Layout: React.FC<{ children: React.ReactNode; currentView: string; setView: (v: string) => void }> = ({ 
  children, 
  currentView, 
  setView 
}) => {
  const { state, loading, syncing, setTheme, setIsAdmin } = useTournament();
  const currentTournament = state.tournaments.find(t => t.id === state.currentTournamentId);
  const isAdmin = state.isAdmin;

  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  const handleAdminLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (username === state.adminUsername && password === state.adminPassword) {
      await setIsAdmin(true);
      setShowPasswordModal(false);
      setUsername('');
      setPassword('');
      setError(false);
    } else {
      setError(true);
      setTimeout(() => setError(false), 2000);
    }
  };

  return (
    <div className={`min-h-screen flex ${state.theme === 'dark' ? 'dark bg-[#0a1a2f]' : 'bg-[#f4f4f4]'}`}>
      {/* Loading Overlay */}
      {loading && (
        <div className="fixed inset-0 z-[300] bg-black/20 backdrop-blur-[2px] flex items-center justify-center pointer-events-auto">
          <div className="bg-white dark:bg-[#0f2238] p-6 rounded-3xl shadow-2xl flex items-center space-x-4 border-2 border-[#8a1538]">
            <Loader2 className="w-6 h-6 text-[#8a1538] animate-spin" />
            <span className="text-[10px] font-black uppercase tracking-widest dark:text-white">Bazaga ulanmoqda...</span>
          </div>
        </div>
      )}

      {/* Sidebar */}
      <aside className="w-80 bg-white dark:bg-[#0f2238] border-r-4 border-[#8a1538] dark:border-[#d4af37] flex flex-col p-8 space-y-10 hidden lg:flex sticky top-0 h-screen z-50">
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 bg-[#8a1538] rounded-2xl flex items-center justify-center shadow-xl shadow-red-900/30">
            <Globe className="w-8 h-8 text-[#d4af37]" />
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-tighter dark:text-white italic-font leading-none uppercase">LigaMaster</h1>
            <p className="text-[9px] font-black text-[#d4af37] uppercase tracking-widest mt-1">{uz.official_hub}</p>
          </div>
        </div>

        <nav className="flex-1 space-y-2 overflow-y-auto custom-scrollbar pr-2">
          <SidebarItem 
            icon={<LayoutDashboard className="w-5 h-5" />} 
            label={uz.dashboard} 
            active={currentView === 'dashboard'} 
            onClick={() => setView('dashboard')} 
          />
          
          {isAdmin && (
            <SidebarItem 
              icon={<Trophy className="w-5 h-5" />} 
              label={uz.tournaments} 
              active={currentView === 'tournaments'} 
              onClick={() => setView('tournaments')} 
            />
          )}
          
          <div className="pt-8 pb-3 px-6">
             <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">{uz.live_feed}</span>
          </div>

          <SidebarItem 
            icon={<Activity className="w-5 h-5" />} 
            label={uz.groups} 
            active={currentView === 'groups'} 
            onClick={() => setView('groups')}
            disabled={!currentTournament}
          />
          <SidebarItem 
            icon={<Table2 className="w-5 h-5" />} 
            label={uz.standings} 
            active={currentView === 'standings'} 
            onClick={() => setView('standings')}
            disabled={!currentTournament}
          />
          <SidebarItem 
            icon={<GitMerge className="w-5 h-5" />} 
            label={uz.playoffs} 
            active={currentView === 'playoffs'} 
            onClick={() => setView('playoffs')}
            disabled={!currentTournament}
          />
          <SidebarItem 
            icon={<CalendarDays className="w-5 h-5" />} 
            label={uz.matches} 
            active={currentView === 'matches'} 
            onClick={() => setView('matches')}
            disabled={!currentTournament}
          />

          {isAdmin && (
            <>
              <div className="pt-8 pb-3 px-6">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">{uz.operations}</span>
              </div>
              <SidebarItem 
                icon={<Users className="w-5 h-5" />} 
                label={uz.teams} 
                active={currentView === 'teams'} 
                onClick={() => setView('teams')}
                disabled={!currentTournament}
              />
              <SidebarItem 
                icon={<Settings className="w-5 h-5" />} 
                label={uz.settings} 
                active={currentView === 'settings'} 
                onClick={() => setView('settings')} 
              />
            </>
          )}
        </nav>

        <div className="pt-6 border-t border-slate-200/50 dark:border-slate-800/50">
          <div className="flex items-center justify-between mb-4 px-2">
            <div className="flex items-center space-x-2">
               <div className={`w-2 h-2 ${syncing ? 'bg-amber-500 animate-spin' : 'bg-emerald-500 animate-pulse'} rounded-full`} />
               <span className="text-[8px] font-black uppercase text-slate-400">
                 {syncing ? 'Sinxronizatsiya...' : 'Server Online'}
               </span>
            </div>
            <Database className="w-3 h-3 text-slate-400" />
          </div>
          <button 
            onClick={() => setTheme(state.theme === 'light' ? 'dark' : 'light')}
            className="w-full flex items-center justify-between px-6 py-4 bg-slate-100 dark:bg-slate-800 rounded-xl text-sm font-bold transition-all"
          >
            <div className="flex items-center space-x-3 text-slate-500 dark:text-slate-400">
              {state.theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
              <span className="uppercase text-[10px] tracking-widest font-black">{state.theme === 'light' ? 'Tungi' : 'Kunduzgi'}</span>
            </div>
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-0 overflow-hidden relative">
        <header className="h-24 bg-white dark:bg-[#0f2238] border-b-4 border-[#8a1538] flex items-center justify-between px-10 sticky top-0 z-40 broadcast-shadow">
          <div className="flex items-center space-x-6">
            <Menu className="w-6 h-6 lg:hidden dark:text-white" />
            <div className="flex flex-col">
              <h2 className="text-2xl font-black dark:text-white uppercase tracking-tighter italic-font leading-none">
                {currentTournament ? currentTournament.name : 'Turnir Portali'}
              </h2>
              <div className="flex items-center space-x-2 mt-1">
                {isAdmin ? (
                   <div className="flex items-center text-[#8a1538] dark:text-[#d4af37] text-[9px] font-black uppercase tracking-widest">
                     <ShieldAlert className="w-3 h-3 mr-1" /> {uz.auth_personnel}
                   </div>
                ) : (
                   <div className="flex items-center text-blue-600 text-[9px] font-black uppercase tracking-widest">
                     <Eye className="w-3 h-3 mr-1" /> {uz.public_viewing}
                   </div>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            {syncing && (
              <div className="hidden sm:flex items-center space-x-2 px-3 py-1.5 bg-amber-50 text-amber-600 rounded-lg border border-amber-200 animate-fifa">
                 <RefreshCw className="w-3 h-3 animate-spin" />
                 <span className="text-[8px] font-black uppercase tracking-widest">Yangilanmoqda</span>
              </div>
            )}
            <div className="hidden sm:flex items-center space-x-3 px-4 py-2 bg-slate-50 dark:bg-[#0a1a2f] rounded-xl border border-slate-100 dark:border-slate-800 mr-4">
               <Wifi className="w-3 h-3 text-emerald-500" />
               <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                 {ApiService.getCloudConfig()?.enabled ? 'Cloud Database' : 'Local Database'}
               </span>
            </div>
            {!isAdmin ? (
              <button 
                onClick={() => setShowPasswordModal(true)}
                className="fifa-btn-gold px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg hover:scale-105 active:scale-95 transition-all"
              >
                {uz.access_dashboard}
              </button>
            ) : (
              <button 
                onClick={() => setIsAdmin(false)}
                className="flex items-center space-x-2 px-6 py-3 bg-red-50 text-red-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-100 transition-all border-2 border-red-200"
              >
                <LogOut className="w-4 h-4" />
                <span>Chiqish</span>
              </button>
            )}
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 lg:p-12 custom-scrollbar">
          {children}
        </div>
      </main>

      {showPasswordModal && (
        <div className="fixed inset-0 bg-[#0a1a2f]/80 backdrop-blur-md flex items-center justify-center z-[200] p-4">
          <div className="bg-white dark:bg-[#0f2238] w-full max-w-md p-12 rounded-[2rem] shadow-2xl border-t-8 border-[#8a1538] dark:border-[#d4af37] animate-fifa">
            <div className="flex flex-col items-center text-center mb-10">
              <div className="w-20 h-20 bg-[#8a1538] rounded-3xl flex items-center justify-center mb-6 shadow-2xl">
                <KeyRound className="w-10 h-10 text-[#d4af37]" />
              </div>
              <h3 className="text-3xl font-black dark:text-white uppercase tracking-tight italic-font">{uz.secure_access}</h3>
              <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mt-2">{uz.enter_credentials}</p>
            </div>

            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div className="relative">
                <User className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input 
                  type="text"
                  autoFocus
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Login..."
                  className="w-full pl-12 pr-6 py-4 rounded-xl bg-slate-50 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-2 border-slate-100 dark:border-slate-800 focus:border-[#8a1538] transition-all"
                />
              </div>

              <div className="relative">
                <Lock className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input 
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Parol..."
                  className="w-full pl-12 pr-6 py-4 rounded-xl bg-slate-50 dark:bg-[#0a1a2f] dark:text-white font-bold outline-none border-2 border-slate-100 dark:border-slate-800 focus:border-[#8a1538] transition-all"
                />
              </div>

              {error && <div className="text-red-600 px-4 py-2 text-[10px] font-black uppercase text-center tracking-widest animate-shake">{uz.incorrect_login}</div>}

              <button 
                type="submit"
                className="w-full py-5 bg-[#8a1538] text-white rounded-xl font-black uppercase text-[12px] tracking-widest shadow-2xl hover:bg-[#5e0e26] transition-all mt-4"
              >
                Kirish
              </button>
              <button 
                type="button"
                onClick={() => setShowPasswordModal(false)}
                className="w-full py-4 text-slate-400 font-bold uppercase text-[9px] tracking-widest"
              >
                Orqaga
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

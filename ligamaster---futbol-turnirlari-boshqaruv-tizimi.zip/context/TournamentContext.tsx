
import React, { createContext, useContext, useState, useEffect, ReactNode, useRef } from 'react';
import { Tournament, AppState, Match, Team, Group } from '../types';
import { ApiService } from '../api';

interface TournamentContextType {
  state: AppState;
  loading: boolean;
  syncing: boolean;
  setIsAdmin: (isAdmin: boolean) => Promise<void>;
  updateAdminCredentials: (username: string, password: string) => Promise<void>;
  createTournament: (params: { name: string; location: string; startDate: string; endDate: string }) => Promise<void>;
  updateTournament: (id: string, params: { name: string; location: string; startDate: string; endDate: string }) => Promise<void>;
  selectTournament: (id: string) => Promise<void>;
  deleteTournament: (id: string) => Promise<void>;
  addMatch: (tournamentId: string, match: Match) => Promise<void>;
  updateMatch: (tournamentId: string, match: Match) => Promise<void>;
  deleteMatch: (tournamentId: string, matchId: string) => Promise<void>;
  addTeamsToGroup: (tournamentId: string, groupId: string, teams: Team[]) => Promise<void>;
  deleteTeam: (tournamentId: string, teamId: string) => Promise<void>;
  addGroup: (tournamentId: string, groupName: string) => Promise<void>;
  deleteGroup: (tournamentId: string, groupId: string) => Promise<void>;
  clearMatches: (tournamentId: string) => Promise<void>;
  setTheme: (theme: 'light' | 'dark') => Promise<void>;
  exportData: () => void;
  importData: (jsonData: string) => boolean;
}

const TournamentContext = createContext<TournamentContextType | undefined>(undefined);

export const TournamentProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppState>({
    currentTournamentId: null,
    tournaments: [],
    isPremiumUser: true,
    isAdmin: false,
    theme: 'light',
    adminUsername: 'admin',
    adminPassword: 'qwe123'
  });
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const syncInterval = useRef<number | null>(null);

  const loadAllData = async (showSyncIndicator = false) => {
    if (showSyncIndicator) setSyncing(true);
    const data = await ApiService.getAppState();
    setState(data);
    if (showSyncIndicator) setSyncing(false);
  };

  useEffect(() => {
    const init = async () => {
      const params = new URLSearchParams(window.location.search);
      const cUrl = params.get('c_url');
      const cKey = params.get('c_key');

      if (cUrl && cKey) {
        await ApiService.saveCloudConfig({
          url: decodeURIComponent(cUrl),
          key: decodeURIComponent(cKey),
          enabled: true
        });
        window.history.replaceState({}, document.title, window.location.pathname);
      }

      await loadAllData();
      setLoading(false);
    };
    init();

    // Avtomatik sinxronizatsiya: Har 30 soniyada (Muxlislar uchun)
    syncInterval.current = window.setInterval(() => {
      const cloud = ApiService.getCloudConfig();
      if (cloud?.enabled && !state.isAdmin) {
        loadAllData(true);
      }
    }, 30000);

    return () => {
      if (syncInterval.current) clearInterval(syncInterval.current);
    };
  }, [state.isAdmin]);

  const setIsAdmin = async (isAdmin: boolean) => {
    setLoading(true);
    await ApiService.updateSettings({ isAdmin });
    setState(prev => ({ ...prev, isAdmin }));
    setLoading(false);
  };

  const updateAdminCredentials = async (username: string, password: string) => {
    setLoading(true);
    await ApiService.updateSettings({ adminUsername: username, adminPassword: password });
    setState(prev => ({ ...prev, adminUsername: username, adminPassword: password }));
    setLoading(false);
  };

  const createTournament = async ({ name, location, startDate, endDate }: { name: string; location: string; startDate: string; endDate: string }) => {
    setLoading(true);
    const newTournament: Tournament = {
      id: crypto.randomUUID(),
      name,
      location,
      startDate,
      endDate,
      isPremium: true,
      groups: [{ id: crypto.randomUUID(), name: 'A guruhi', teams: [] }],
      matches: [],
      teams: [],
      createdAt: new Date().toISOString()
    };
    await ApiService.saveTournament(newTournament);
    await loadAllData();
    setLoading(false);
  };

  const updateTournament = async (id: string, params: { name: string; location: string; startDate: string; endDate: string }) => {
    setLoading(true);
    const tourn = state.tournaments.find(t => t.id === id);
    if (tourn) {
      await ApiService.saveTournament({ ...tourn, ...params });
      await loadAllData();
    }
    setLoading(false);
  };

  const selectTournament = async (id: string) => {
    setLoading(true);
    await ApiService.updateSettings({ currentTournamentId: id });
    setState(prev => ({ ...prev, currentTournamentId: id }));
    setLoading(false);
  };

  const deleteTournament = async (id: string) => {
    setLoading(true);
    await ApiService.deleteTournament(id);
    await loadAllData();
    setLoading(false);
  };

  const addMatch = async (tournamentId: string, match: Match) => {
    setLoading(true);
    const t = state.tournaments.find(tourn => tourn.id === tournamentId);
    if (t) {
      await ApiService.saveTournament({ ...t, matches: [...t.matches, match] });
      await loadAllData();
    }
    setLoading(false);
  };

  const updateMatch = async (tournamentId: string, updatedMatch: Match) => {
    setLoading(true);
    const t = state.tournaments.find(tourn => tourn.id === tournamentId);
    if (t) {
      const updated = {
        ...t,
        matches: t.matches.map(m => m.id === updatedMatch.id ? updatedMatch : m)
      };
      await ApiService.saveTournament(updated);
      await loadAllData();
    }
    setLoading(false);
  };

  const deleteMatch = async (tournamentId: string, matchId: string) => {
    setLoading(true);
    const t = state.tournaments.find(tourn => tourn.id === tournamentId);
    if (t) {
      await ApiService.saveTournament({ ...t, matches: t.matches.filter(m => m.id !== matchId) });
      await loadAllData();
    }
    setLoading(false);
  };

  const addTeamsToGroup = async (tournamentId: string, groupId: string, teams: Team[]) => {
    setLoading(true);
    const t = state.tournaments.find(tourn => tourn.id === tournamentId);
    if (t) {
      const newTeams = [...t.teams, ...teams];
      const newGroups = t.groups.map(g => 
        g.id === groupId ? { ...g, teams: [...g.teams, ...teams.map(tm => tm.id)] } : g
      );
      await ApiService.saveTournament({ ...t, teams: newTeams, groups: newGroups });
      await loadAllData();
    }
    setLoading(false);
  };

  const deleteTeam = async (tournamentId: string, teamId: string) => {
    setLoading(true);
    const t = state.tournaments.find(tourn => tourn.id === tournamentId);
    if (t) {
      const updated = {
        ...t,
        teams: t.teams.filter(team => team.id !== teamId),
        groups: t.groups.map(g => ({
          ...g,
          teams: g.teams.filter(tid => tid !== teamId)
        })),
        matches: t.matches.filter(m => m.homeTeamId !== teamId && m.awayTeamId !== teamId)
      };
      await ApiService.saveTournament(updated);
      await loadAllData();
    }
    setLoading(false);
  };

  const addGroup = async (tournamentId: string, groupName: string) => {
    setLoading(true);
    const t = state.tournaments.find(tourn => tourn.id === tournamentId);
    if (t) {
      const newGroup: Group = { id: crypto.randomUUID(), name: groupName, teams: [] };
      await ApiService.saveTournament({ ...t, groups: [...t.groups, newGroup] });
      await loadAllData();
    }
    setLoading(false);
  };

  const deleteGroup = async (tournamentId: string, groupId: string) => {
    setLoading(true);
    const t = state.tournaments.find(tourn => tourn.id === tournamentId);
    if (t) {
      const groupToDelete = t.groups.find(g => g.id === groupId);
      if (groupToDelete) {
        const teamIdsToDelete = groupToDelete.teams;
        const updated = {
          ...t,
          groups: t.groups.filter(g => g.id !== groupId),
          teams: t.teams.filter(team => !teamIdsToDelete.includes(team.id)),
          matches: t.matches.filter(m => !teamIdsToDelete.includes(m.homeTeamId) && !teamIdsToDelete.includes(m.awayTeamId))
        };
        await ApiService.saveTournament(updated);
        await loadAllData();
      }
    }
    setLoading(false);
  };

  const clearMatches = async (tournamentId: string) => {
    setLoading(true);
    const t = state.tournaments.find(tourn => tourn.id === tournamentId);
    if (t) {
      await ApiService.saveTournament({ ...t, matches: [] });
      await loadAllData();
    }
    setLoading(false);
  };

  const setTheme = async (theme: 'light' | 'dark') => {
    await ApiService.updateSettings({ theme });
    setState(prev => ({ ...prev, theme }));
  };

  const exportData = () => {
    const dataStr = JSON.stringify(state, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `ligamaster_db_backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const importData = (jsonData: string): boolean => {
    try {
      const parsed = JSON.parse(jsonData);
      if (parsed.tournaments) {
        ApiService.saveRawData(parsed);
        setState(parsed);
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  };

  return (
    <TournamentContext.Provider value={{ 
      state, 
      loading,
      syncing,
      setIsAdmin,
      updateAdminCredentials,
      createTournament, 
      updateTournament,
      selectTournament, 
      deleteTournament, 
      addMatch,
      updateMatch, 
      deleteMatch,
      addTeamsToGroup,
      deleteTeam,
      addGroup,
      deleteGroup,
      clearMatches,
      setTheme,
      exportData,
      importData
    }}>
      {children}
    </TournamentContext.Provider>
  );
};

export const useTournament = () => {
  const context = useContext(TournamentContext);
  if (!context) throw new Error('useTournament must be used within TournamentProvider');
  return context;
};
